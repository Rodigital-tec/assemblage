// Fonctionnalités avancées de messagerie : Groupes, programmation, threads, etc.
class AdvancedMessagingFeatures {
    constructor() {
        this.groups = {};
        this.scheduledMessages = [];
        this.typingUsers = new Set();
        this.favorites = new Set();
        this.blockedUsers = new Set();
        this.darkMode = localStorage.getItem('darkMode') === 'true';
        
        this.initializeAdvancedFeatures();
    }

    initializeAdvancedFeatures() {
        this.setupGroupMessaging();
        this.setupScheduledMessages();
        this.setupTypingIndicator();
        this.setupMessageThreads();
        this.setupFavorites();
        this.setupDarkMode();
        this.setupKeyboardShortcuts();
        this.setupAdvancedSearch();
        this.addAdvancedStyles();
    }

    // === CONVERSATIONS DE GROUPE ===
    
    setupGroupMessaging() {
        // Données de test pour les groupes
        this.groups = {
            'group-1': {
                id: 'group-1',
                name: 'Aide Quartier Centre',
                description: 'Groupe d\'entraide pour le quartier centre-ville',
                avatar: 'AQ',
                members: [
                    { id: 'marie', name: 'Marie Dupont', role: 'member' },
                    { id: 'jean', name: 'Jean Petit', role: 'admin' },
                    { id: 'pierre', name: 'Pierre Martin', role: 'member' },
                    { id: 'me', name: 'Sophie Leroy', role: 'admin' }
                ],
                messages: [
                    {
                        id: 1,
                        sender: 'jean',
                        content: 'Bonjour tout le monde ! Bienvenue dans notre groupe d\'entraide.',
                        time: '15/01/2024',
                        read: true,
                        reactions: [
                            { emoji: '👋', count: 3, users: ['marie', 'pierre', 'me'] }
                        ]
                    },
                    {
                        id: 2,
                        sender: 'marie',
                        content: 'Merci Jean ! J\'ai hâte de pouvoir aider et être aidée.',
                        time: '15/01/2024',
                        read: true,
                        reactions: []
                    },
                    {
                        id: 3,
                        sender: 'me',
                        content: 'Excellente initiative ! Je suis disponible pour les courses et le ménage.',
                        time: 'Aujourd\'hui',
                        read: false,
                        reactions: [
                            { emoji: '👍', count: 2, users: ['jean', 'marie'] }
                        ]
                    }
                ],
                created: '15/01/2024',
                lastActivity: 'Aujourd\'hui'
            }
        };
    }

    createGroup(name, description, members) {
        const groupId = 'group-' + Date.now();
        const group = {
            id: groupId,
            name: name,
            description: description,
            avatar: name.substring(0, 2).toUpperCase(),
            members: [
                ...members,
                { id: 'me', name: 'Sophie Leroy', role: 'admin' }
            ],
            messages: [],
            created: new Date().toLocaleDateString('fr-FR'),
            lastActivity: new Date().toLocaleDateString('fr-FR')
        };
        
        this.groups[groupId] = group;
        this.addGroupToConversationsList(group);
        return groupId;
    }

    addGroupToConversationsList(group) {
        const conversationsList = document.getElementById('conversationsList');
        if (!conversationsList) return;

        const groupElement = document.createElement('div');
        groupElement.className = 'conversation-item group-conversation';
        groupElement.dataset.user = group.id;
        groupElement.onclick = () => this.selectGroupConversation(group.id);
        
        groupElement.innerHTML = `
            <div class="conversation-avatar group-avatar">
                ${group.avatar}
                <div class="group-indicator">
                    <i class="fas fa-users"></i>
                </div>
            </div>
            <div class="conversation-info">
                <h3 class="conversation-name">
                    ${group.name}
                    <span class="group-members-count">${group.members.length} membres</span>
                </h3>
                <p class="conversation-preview">${group.description}</p>
            </div>
            <div class="conversation-meta">
                <span class="conversation-time">${group.lastActivity}</span>
                ${group.messages.some(m => !m.read) ? '<span class="unread-badge">1</span>' : ''}
            </div>
        `;
        
        conversationsList.insertBefore(groupElement, conversationsList.firstChild);
    }

    selectGroupConversation(groupId) {
        const group = this.groups[groupId];
        if (!group) return;

        // Mettre à jour l'interface
        document.querySelectorAll('.conversation-item').forEach(item => {
            item.classList.remove('active');
        });
        document.querySelector(`[data-user="${groupId}"]`).classList.add('active');

        // Charger la conversation de groupe
        this.loadGroupConversation(groupId);
    }

    loadGroupConversation(groupId) {
        const group = this.groups[groupId];
        if (!group) return;

        // Mettre à jour l'en-tête
        document.getElementById('chatUserName').innerHTML = `
            ${group.name}
            <span style="font-size: 0.8rem; font-weight: 400; color: #6c757d;">
                ${group.members.length} membres
            </span>
        `;
        document.getElementById('chatUserStatus').textContent = group.description;
        document.getElementById('chatAvatar').textContent = group.avatar;

        // Ajouter le bouton d'informations du groupe
        this.addGroupInfoButton(groupId);

        // Charger les messages
        const messagesArea = document.getElementById('messagesArea');
        messagesArea.innerHTML = '';

        group.messages.forEach(message => {
            const messageElement = this.createGroupMessageElement(message, group);
            messagesArea.appendChild(messageElement);
        });

        // Scroll vers le bas
        messagesArea.scrollTop = messagesArea.scrollHeight;
    }

    createGroupMessageElement(message, group) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${message.sender === 'me' ? 'sent' : 'received'}`;
        messageDiv.dataset.messageId = message.id;

        const sender = group.members.find(m => m.id === message.sender);
        const senderName = sender ? sender.name : 'Utilisateur inconnu';
        const senderInitials = senderName.split(' ').map(n => n[0]).join('').substring(0, 2);

        const avatar = document.createElement('div');
        avatar.className = 'message-avatar';
        avatar.textContent = message.sender === 'me' ? 'V' : senderInitials;
        avatar.title = senderName;

        const content = document.createElement('div');
        content.className = 'message-content';

        // Nom de l'expéditeur pour les groupes
        if (message.sender !== 'me') {
            const senderLabel = document.createElement('div');
            senderLabel.className = 'message-sender';
            senderLabel.textContent = senderName;
            content.appendChild(senderLabel);
        }

        const bubble = document.createElement('div');
        bubble.className = 'message-bubble';
        bubble.textContent = message.content;

        const time = document.createElement('div');
        time.className = 'message-time';
        time.innerHTML = `
            ${message.time}
            ${message.sender === 'me' ? `
                <span class="read-status ${message.read ? 'read' : 'delivered'}">
                    <i class="fas fa-check${message.read ? '-double' : ''}"></i>
                    ${message.read ? 'Lu' : 'Livré'}
                </span>
            ` : ''}
        `;

        // Réactions
        const reactions = document.createElement('div');
        reactions.className = 'message-reactions';
        
        message.reactions.forEach(reaction => {
            const reactionElement = document.createElement('div');
            reactionElement.className = 'reaction';
            reactionElement.innerHTML = `
                <span class="reaction-emoji">${reaction.emoji}</span>
                <span class="reaction-count">${reaction.count}</span>
            `;
            reactions.appendChild(reactionElement);
        });

        content.appendChild(bubble);
        content.appendChild(time);
        content.appendChild(reactions);

        messageDiv.appendChild(avatar);
        messageDiv.appendChild(content);

        return messageDiv;
    }

    addGroupInfoButton(groupId) {
        const chatActions = document.querySelector('.chat-actions');
        if (!chatActions) return;

        // Supprimer l'ancien bouton s'il existe
        const existingBtn = chatActions.querySelector('.group-info-btn');
        if (existingBtn) existingBtn.remove();

        const groupInfoBtn = document.createElement('button');
        groupInfoBtn.className = 'chat-action-btn group-info-btn';
        groupInfoBtn.title = 'Informations du groupe';
        groupInfoBtn.innerHTML = '<i class="fas fa-users"></i>';
        groupInfoBtn.onclick = () => this.showGroupInfo(groupId);
        
        chatActions.appendChild(groupInfoBtn);
    }

    showGroupInfo(groupId) {
        const group = this.groups[groupId];
        if (!group) return;

        const modal = document.createElement('div');
        modal.className = 'modal-overlay';
        modal.innerHTML = `
            <div class="modal-content group-info-modal">
                <div class="modal-header">
                    <h3><i class="fas fa-users"></i> ${group.name}</h3>
                    <button class="modal-close" onclick="this.closest('.modal-overlay').remove()">×</button>
                </div>
                <div class="modal-body">
                    <div class="group-details">
                        <div class="group-avatar-large">${group.avatar}</div>
                        <div class="group-description">${group.description}</div>
                        <div class="group-stats">
                            <div class="stat">
                                <i class="fas fa-users"></i>
                                <span>${group.members.length} membres</span>
                            </div>
                            <div class="stat">
                                <i class="fas fa-calendar"></i>
                                <span>Créé le ${group.created}</span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="group-members">
                        <h4>Membres du groupe</h4>
                        <div class="members-list">
                            ${group.members.map(member => `
                                <div class="member-item">
                                    <div class="member-avatar">${member.name.split(' ').map(n => n[0]).join('')}</div>
                                    <div class="member-info">
                                        <div class="member-name">${member.name}</div>
                                        <div class="member-role">${member.role === 'admin' ? 'Administrateur' : 'Membre'}</div>
                                    </div>
                                    ${member.role === 'admin' ? '<i class="fas fa-crown admin-crown"></i>' : ''}
                                </div>
                            `).join('')}
                        </div>
                    </div>
                    
                    <div class="group-actions">
                        <button class="btn-secondary" onclick="advancedFeatures.addMemberToGroup('${groupId}')">
                            <i class="fas fa-user-plus"></i> Ajouter un membre
                        </button>
                        <button class="btn-secondary" onclick="advancedFeatures.editGroup('${groupId}')">
                            <i class="fas fa-edit"></i> Modifier le groupe
                        </button>
                        <button class="btn-danger" onclick="advancedFeatures.leaveGroup('${groupId}')">
                            <i class="fas fa-sign-out-alt"></i> Quitter le groupe
                        </button>
                    </div>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
    }

    // === MESSAGES PROGRAMMÉS ===
    
    setupScheduledMessages() {
        this.scheduledMessages = [];
    }

    scheduleMessage(content, recipientId, scheduledTime) {
        const scheduledMessage = {
            id: Date.now(),
            content: content,
            recipientId: recipientId,
            scheduledTime: scheduledTime,
            status: 'pending',
            created: new Date()
        };
        
        this.scheduledMessages.push(scheduledMessage);
        this.setMessageTimer(scheduledMessage);
        
        return scheduledMessage.id;
    }

    setMessageTimer(scheduledMessage) {
        const delay = scheduledMessage.scheduledTime.getTime() - Date.now();
        
        if (delay > 0) {
            setTimeout(() => {
                this.sendScheduledMessage(scheduledMessage);
            }, delay);
        }
    }

    sendScheduledMessage(scheduledMessage) {
        // Simuler l'envoi du message programmé
        const message = {
            id: Date.now(),
            sender: 'me',
            content: scheduledMessage.content,
            time: 'Maintenant',
            read: false,
            reactions: [],
            scheduled: true
        };

        // Ajouter à la conversation appropriée
        if (window.conversations && window.conversations[scheduledMessage.recipientId]) {
            window.conversations[scheduledMessage.recipientId].messages.push(message);
            
            // Mettre à jour l'interface si c'est la conversation active
            if (window.currentConversation === scheduledMessage.recipientId) {
                const messageElement = window.createMessageElement(message);
                document.getElementById('messagesArea').appendChild(messageElement);
            }
        }

        // Marquer comme envoyé
        scheduledMessage.status = 'sent';
        
        this.showNotification('Message programmé envoyé', 'success');
    }

    showScheduleMessageModal() {
        const modal = document.createElement('div');
        modal.className = 'modal-overlay';
        modal.innerHTML = `
            <div class="modal-content schedule-message-modal">
                <div class="modal-header">
                    <h3><i class="fas fa-clock"></i> Programmer un message</h3>
                    <button class="modal-close" onclick="this.closest('.modal-overlay').remove()">×</button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label>Message</label>
                        <textarea class="form-textarea" placeholder="Tapez votre message..." id="scheduledMessageContent"></textarea>
                    </div>
                    <div class="form-group">
                        <label>Date et heure d'envoi</label>
                        <input type="datetime-local" class="form-input" id="scheduledDateTime" min="${new Date().toISOString().slice(0, 16)}">
                    </div>
                    <div class="form-group">
                        <label>Destinataire</label>
                        <select class="form-select" id="scheduledRecipient">
                            <option value="marie">Marie Dupont</option>
                            <option value="jean">Jean Petit</option>
                            <option value="pierre">Pierre Martin</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn-secondary" onclick="this.closest('.modal-overlay').remove()">Annuler</button>
                    <button class="btn-primary" onclick="advancedFeatures.confirmScheduleMessage()">Programmer</button>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
    }

    confirmScheduleMessage() {
        const content = document.getElementById('scheduledMessageContent').value.trim();
        const dateTime = document.getElementById('scheduledDateTime').value;
        const recipient = document.getElementById('scheduledRecipient').value;
        
        if (!content || !dateTime || !recipient) {
            this.showNotification('Veuillez remplir tous les champs', 'error');
            return;
        }
        
        const scheduledTime = new Date(dateTime);
        if (scheduledTime <= new Date()) {
            this.showNotification('La date doit être dans le futur', 'error');
            return;
        }
        
        this.scheduleMessage(content, recipient, scheduledTime);
        document.querySelector('.modal-overlay').remove();
        
        this.showNotification('Message programmé avec succès', 'success');
    }

    // === INDICATEUR DE FRAPPE ===
    
    setupTypingIndicator() {
        const messageInput = document.getElementById('messageInput');
        if (!messageInput) return;

        let typingTimer;
        
        messageInput.addEventListener('input', () => {
            this.showTypingIndicator();
            
            clearTimeout(typingTimer);
            typingTimer = setTimeout(() => {
                this.hideTypingIndicator();
            }, 3000);
        });

        messageInput.addEventListener('blur', () => {
            this.hideTypingIndicator();
        });
    }

    showTypingIndicator() {
        // Simuler que l'autre utilisateur voit qu'on tape
        const existingIndicator = document.querySelector('.typing-indicator');
        if (existingIndicator) return;

        const indicator = document.createElement('div');
        indicator.className = 'typing-indicator';
        indicator.innerHTML = `
            <div class="typing-avatar">V</div>
            <div class="typing-bubble">
                <div class="typing-dots">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </div>
        `;
        
        const messagesArea = document.getElementById('messagesArea');
        if (messagesArea) {
            messagesArea.appendChild(indicator);
            messagesArea.scrollTop = messagesArea.scrollHeight;
        }
    }

    hideTypingIndicator() {
        const indicator = document.querySelector('.typing-indicator');
        if (indicator) {
            indicator.remove();
        }
    }

    // === THREADS DE MESSAGES ===
    
    setupMessageThreads() {
        // Ajouter la possibilité de répondre à un message spécifique
        document.addEventListener('contextmenu', (e) => {
            const message = e.target.closest('.message');
            if (message && !message.classList.contains('sent')) {
                e.preventDefault();
                this.showMessageContextMenu(e, message);
            }
        });
    }

    showMessageContextMenu(event, messageElement) {
        const contextMenu = document.createElement('div');
        contextMenu.className = 'context-menu';
        contextMenu.innerHTML = `
            <div class="context-menu-item" onclick="advancedFeatures.replyToMessage('${messageElement.dataset.messageId}')">
                <i class="fas fa-reply"></i> Répondre
            </div>
            <div class="context-menu-item" onclick="advancedFeatures.addToFavorites('${messageElement.dataset.messageId}')">
                <i class="fas fa-star"></i> Ajouter aux favoris
            </div>
            <div class="context-menu-item" onclick="advancedFeatures.copyMessage('${messageElement.dataset.messageId}')">
                <i class="fas fa-copy"></i> Copier
            </div>
            <div class="context-menu-item danger" onclick="advancedFeatures.reportMessage('${messageElement.dataset.messageId}')">
                <i class="fas fa-flag"></i> Signaler
            </div>
        `;
        
        contextMenu.style.left = event.pageX + 'px';
        contextMenu.style.top = event.pageY + 'px';
        
        document.body.appendChild(contextMenu);
        
        // Fermer au clic ailleurs
        setTimeout(() => {
            document.addEventListener('click', function closeMenu() {
                contextMenu.remove();
                document.removeEventListener('click', closeMenu);
            });
        }, 100);
    }

    replyToMessage(messageId) {
        const messageInput = document.getElementById('messageInput');
        if (!messageInput) return;

        // Trouver le message original
        const originalMessage = this.findMessageById(messageId);
        if (!originalMessage) return;

        // Afficher l'interface de réponse
        this.showReplyInterface(originalMessage);
        messageInput.focus();
    }

    showReplyInterface(originalMessage) {
        const existingReply = document.querySelector('.reply-interface');
        if (existingReply) existingReply.remove();

        const replyInterface = document.createElement('div');
        replyInterface.className = 'reply-interface';
        replyInterface.innerHTML = `
            <div class="reply-content">
                <div class="reply-header">
                    <i class="fas fa-reply"></i>
                    <span>Réponse à ${originalMessage.senderName || 'ce message'}</span>
                    <button class="reply-close" onclick="this.closest('.reply-interface').remove()">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="reply-preview">${originalMessage.content.substring(0, 100)}${originalMessage.content.length > 100 ? '...' : ''}</div>
            </div>
        `;
        
        const messageInputArea = document.querySelector('.message-input-area');
        messageInputArea.insertBefore(replyInterface, messageInputArea.firstChild);
    }

    // === FAVORIS ===
    
    setupFavorites() {
        this.favorites = new Set(JSON.parse(localStorage.getItem('messageFavorites') || '[]'));
    }

    addToFavorites(messageId) {
        this.favorites.add(messageId);
        localStorage.setItem('messageFavorites', JSON.stringify([...this.favorites]));
        this.showNotification('Message ajouté aux favoris', 'success');
    }

    removeFromFavorites(messageId) {
        this.favorites.delete(messageId);
        localStorage.setItem('messageFavorites', JSON.stringify([...this.favorites]));
        this.showNotification('Message retiré des favoris', 'info');
    }

    showFavorites() {
        // Afficher la liste des messages favoris
        const modal = document.createElement('div');
        modal.className = 'modal-overlay';
        modal.innerHTML = `
            <div class="modal-content favorites-modal">
                <div class="modal-header">
                    <h3><i class="fas fa-star"></i> Messages favoris</h3>
                    <button class="modal-close" onclick="this.closest('.modal-overlay').remove()">×</button>
                </div>
                <div class="modal-body">
                    <div class="favorites-list" id="favoritesList">
                        ${this.favorites.size === 0 ? 
                            '<div class="empty-state"><i class="fas fa-star"></i><p>Aucun message favori</p></div>' :
                            this.renderFavoriteMessages()
                        }
                    </div>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
    }

    // === MODE SOMBRE ===
    
    setupDarkMode() {
        if (this.darkMode) {
            document.body.classList.add('dark-mode');
        }
        
        this.addDarkModeToggle();
    }

    addDarkModeToggle() {
        const chatActions = document.querySelector('.chat-actions');
        if (!chatActions) return;

        const darkModeBtn = document.createElement('button');
        darkModeBtn.className = 'chat-action-btn dark-mode-toggle';
        darkModeBtn.title = 'Mode sombre';
        darkModeBtn.innerHTML = `<i class="fas fa-${this.darkMode ? 'sun' : 'moon'}"></i>`;
        darkModeBtn.onclick = () => this.toggleDarkMode();
        
        chatActions.appendChild(darkModeBtn);
    }

    toggleDarkMode() {
        this.darkMode = !this.darkMode;
        document.body.classList.toggle('dark-mode', this.darkMode);
        localStorage.setItem('darkMode', this.darkMode.toString());
        
        const toggle = document.querySelector('.dark-mode-toggle i');
        if (toggle) {
            toggle.className = `fas fa-${this.darkMode ? 'sun' : 'moon'}`;
        }
    }

    // === RACCOURCIS CLAVIER ===
    
    setupKeyboardShortcuts() {
        document.addEventListener('keydown', (e) => {
            // Ctrl/Cmd + Enter pour envoyer
            if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
                e.preventDefault();
                if (window.sendMessage) window.sendMessage();
            }
            
            // Ctrl/Cmd + K pour rechercher
            if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
                e.preventDefault();
                document.getElementById('searchInput')?.focus();
            }
            
            // Échap pour fermer les modals
            if (e.key === 'Escape') {
                const modal = document.querySelector('.modal-overlay');
                if (modal) modal.remove();
                
                const contextMenu = document.querySelector('.context-menu');
                if (contextMenu) contextMenu.remove();
            }
        });
    }

    // === RECHERCHE AVANCÉE ===
    
    setupAdvancedSearch() {
        const searchInput = document.getElementById('searchInput');
        if (!searchInput) return;

        // Ajouter un bouton de recherche avancée
        const searchContainer = searchInput.parentElement;
        const advancedBtn = document.createElement('button');
        advancedBtn.className = 'advanced-search-btn';
        advancedBtn.innerHTML = '<i class="fas fa-filter"></i>';
        advancedBtn.title = 'Recherche avancée';
        advancedBtn.onclick = () => this.showAdvancedSearch();
        
        searchContainer.appendChild(advancedBtn);
    }

    showAdvancedSearch() {
        const modal = document.createElement('div');
        modal.className = 'modal-overlay';
        modal.innerHTML = `
            <div class="modal-content advanced-search-modal">
                <div class="modal-header">
                    <h3><i class="fas fa-search"></i> Recherche avancée</h3>
                    <button class="modal-close" onclick="this.closest('.modal-overlay').remove()">×</button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label>Texte à rechercher</label>
                        <input type="text" class="form-input" placeholder="Mots-clés..." id="searchText">
                    </div>
                    <div class="form-group">
                        <label>Expéditeur</label>
                        <select class="form-select" id="searchSender">
                            <option value="">Tous</option>
                            <option value="me">Moi</option>
                            <option value="marie">Marie Dupont</option>
                            <option value="jean">Jean Petit</option>
                            <option value="pierre">Pierre Martin</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Type de message</label>
                        <select class="form-select" id="searchType">
                            <option value="">Tous</option>
                            <option value="text">Texte</option>
                            <option value="file">Fichier</option>
                            <option value="voice">Vocal</option>
                            <option value="location">Localisation</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Période</label>
                        <div class="date-range">
                            <input type="date" class="form-input" id="searchDateFrom">
                            <span>à</span>
                            <input type="date" class="form-input" id="searchDateTo">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn-secondary" onclick="this.closest('.modal-overlay').remove()">Annuler</button>
                    <button class="btn-primary" onclick="advancedFeatures.performAdvancedSearch()">Rechercher</button>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
    }

    // === UTILITAIRES ===
    
    findMessageById(messageId) {
        // Rechercher dans toutes les conversations
        for (const conversationId in window.conversations) {
            const message = window.conversations[conversationId].messages.find(m => m.id == messageId);
            if (message) {
                return {
                    ...message,
                    conversationId: conversationId,
                    senderName: conversationId === 'me' ? 'Vous' : window.conversations[conversationId].name
                };
            }
        }
        
        // Rechercher dans les groupes
        for (const groupId in this.groups) {
            const message = this.groups[groupId].messages.find(m => m.id == messageId);
            if (message) {
                const sender = this.groups[groupId].members.find(m => m.id === message.sender);
                return {
                    ...message,
                    conversationId: groupId,
                    senderName: sender ? sender.name : 'Utilisateur inconnu'
                };
            }
        }
        
        return null;
    }

    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        notification.innerHTML = `
            <i class="fas fa-${type === 'success' ? 'check' : type === 'error' ? 'exclamation-triangle' : 'info'}"></i>
            <span>${message}</span>
        `;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.classList.add('show');
        }, 100);
        
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => notification.remove(), 300);
        }, 3000);
    }

    copyMessage(messageId) {
        const message = this.findMessageById(messageId);
        if (message && message.content) {
            navigator.clipboard.writeText(message.content).then(() => {
                this.showNotification('Message copié', 'success');
            });
        }
    }

    reportMessage(messageId) {
        // Simuler le signalement
        this.showNotification('Message signalé aux modérateurs', 'info');
    }

    // === STYLES ===
    
    addAdvancedStyles() {
        const style = document.createElement('style');
        style.textContent = `
            /* Conversations de groupe */
            .group-conversation .conversation-avatar {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                position: relative;
            }
            
            .group-indicator {
                position: absolute;
                bottom: -2px;
                right: -2px;
                background: #28a745;
                border: 2px solid white;
                border-radius: 50%;
                width: 16px;
                height: 16px;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 0.6rem;
                color: white;
            }
            
            .group-members-count {
                font-size: 0.7rem;
                color: #6c757d;
                font-weight: 400;
                margin-left: 0.5rem;
            }
            
            .message-sender {
                font-size: 0.75rem;
                color: #6c757d;
                font-weight: 600;
                margin-bottom: 0.25rem;
                font-family: 'Montserrat', sans-serif;
            }
            
            /* Indicateur de frappe */
            .typing-indicator {
                display: flex;
                align-items: center;
                gap: 0.75rem;
                margin: 1rem 0;
                opacity: 0.7;
            }
            
            .typing-avatar {
                width: 35px;
                height: 35px;
                border-radius: 50%;
                background: #e9ecef;
                display: flex;
                align-items: center;
                justify-content: center;
                font-family: 'Montserrat', sans-serif;
                font-weight: 600;
                font-size: 0.9rem;
                color: #6c757d;
            }
            
            .typing-bubble {
                background: #f8f9fa;
                padding: 1rem 1.25rem;
                border-radius: 20px;
            }
            
            .typing-dots {
                display: flex;
                gap: 0.25rem;
            }
            
            .typing-dots span {
                width: 8px;
                height: 8px;
                border-radius: 50%;
                background: #6c757d;
                animation: typing 1.4s infinite ease-in-out;
            }
            
            .typing-dots span:nth-child(1) { animation-delay: -0.32s; }
            .typing-dots span:nth-child(2) { animation-delay: -0.16s; }
            
            @keyframes typing {
                0%, 80%, 100% { transform: scale(0.8); opacity: 0.5; }
                40% { transform: scale(1); opacity: 1; }
            }
            
            /* Interface de réponse */
            .reply-interface {
                background: linear-gradient(135deg, rgba(154, 205, 50, 0.1), rgba(0, 206, 209, 0.1));
                border-left: 4px solid var(--primary-green);
                margin-bottom: 1rem;
                border-radius: 10px;
                overflow: hidden;
            }
            
            .reply-content {
                padding: 1rem;
            }
            
            .reply-header {
                display: flex;
                align-items: center;
                gap: 0.5rem;
                font-family: 'Montserrat', sans-serif;
                font-weight: 600;
                font-size: 0.9rem;
                color: var(--primary-green);
                margin-bottom: 0.5rem;
            }
            
            .reply-close {
                background: none;
                border: none;
                color: #6c757d;
                cursor: pointer;
                margin-left: auto;
                padding: 0.25rem;
                border-radius: 50%;
                transition: all 0.3s ease;
            }
            
            .reply-close:hover {
                background: rgba(0,0,0,0.1);
            }
            
            .reply-preview {
                font-family: 'Montserrat', sans-serif;
                font-size: 0.85rem;
                color: #6c757d;
                font-style: italic;
            }
            
            /* Menu contextuel */
            .context-menu {
                position: absolute;
                background: white;
                border-radius: 10px;
                box-shadow: 0 4px 20px rgba(0,0,0,0.15);
                padding: 0.5rem 0;
                z-index: 10000;
                min-width: 150px;
            }
            
            .context-menu-item {
                padding: 0.75rem 1rem;
                cursor: pointer;
                transition: all 0.3s ease;
                display: flex;
                align-items: center;
                gap: 0.5rem;
                font-family: 'Montserrat', sans-serif;
                font-size: 0.9rem;
            }
            
            .context-menu-item:hover {
                background: var(--light-gray);
            }
            
            .context-menu-item.danger {
                color: #dc3545;
            }
            
            .context-menu-item.danger:hover {
                background: rgba(220, 53, 69, 0.1);
            }
            
            /* Notifications */
            .notification {
                position: fixed;
                top: 20px;
                right: 20px;
                background: white;
                border-radius: 10px;
                padding: 1rem 1.5rem;
                box-shadow: 0 4px 20px rgba(0,0,0,0.15);
                display: flex;
                align-items: center;
                gap: 0.5rem;
                font-family: 'Montserrat', sans-serif;
                font-weight: 500;
                z-index: 10000;
                transform: translateX(100%);
                transition: transform 0.3s ease;
            }
            
            .notification.show {
                transform: translateX(0);
            }
            
            .notification-success {
                border-left: 4px solid #28a745;
                color: #28a745;
            }
            
            .notification-error {
                border-left: 4px solid #dc3545;
                color: #dc3545;
            }
            
            .notification-info {
                border-left: 4px solid #17a2b8;
                color: #17a2b8;
            }
            
            /* Recherche avancée */
            .advanced-search-btn {
                position: absolute;
                right: 0.5rem;
                top: 50%;
                transform: translateY(-50%);
                background: none;
                border: none;
                color: #6c757d;
                cursor: pointer;
                padding: 0.5rem;
                border-radius: 50%;
                transition: all 0.3s ease;
            }
            
            .advanced-search-btn:hover {
                background: var(--light-gray);
                color: var(--primary-green);
            }
            
            .date-range {
                display: flex;
                align-items: center;
                gap: 0.5rem;
            }
            
            .date-range span {
                font-family: 'Montserrat', sans-serif;
                color: #6c757d;
            }
            
            /* Mode sombre */
            .dark-mode {
                --light-gray: #2c2c2c;
                --medium-gray: #3c3c3c;
                --dark-gray: #e0e0e0;
                background: #1a1a1a;
                color: #e0e0e0;
            }
            
            .dark-mode .messages-container {
                background: #1a1a1a;
            }
            
            .dark-mode .conversations-panel,
            .dark-mode .chat-panel {
                background: #2c2c2c;
                color: #e0e0e0;
            }
            
            .dark-mode .message-bubble {
                background: #3c3c3c;
                color: #e0e0e0;
            }
            
            .dark-mode .message.sent .message-bubble {
                background: var(--gradient-primary);
                color: white;
            }
            
            .dark-mode .search-input {
                background: #3c3c3c;
                border-color: #4c4c4c;
                color: #e0e0e0;
            }
            
            .dark-mode .conversation-item:hover {
                background: #3c3c3c;
            }
            
            /* Modals pour groupes */
            .group-info-modal {
                max-width: 500px;
            }
            
            .group-details {
                text-align: center;
                margin-bottom: 2rem;
            }
            
            .group-avatar-large {
                width: 80px;
                height: 80px;
                border-radius: 50%;
                background: var(--gradient-primary);
                display: flex;
                align-items: center;
                justify-content: center;
                color: white;
                font-family: 'Montserrat', sans-serif;
                font-weight: 700;
                font-size: 2rem;
                margin: 0 auto 1rem auto;
            }
            
            .group-description {
                font-family: 'Montserrat', sans-serif;
                color: #6c757d;
                margin-bottom: 1rem;
            }
            
            .group-stats {
                display: flex;
                justify-content: center;
                gap: 2rem;
            }
            
            .stat {
                display: flex;
                align-items: center;
                gap: 0.5rem;
                font-family: 'Montserrat', sans-serif;
                font-size: 0.9rem;
                color: #6c757d;
            }
            
            .members-list {
                max-height: 300px;
                overflow-y: auto;
            }
            
            .member-item {
                display: flex;
                align-items: center;
                gap: 1rem;
                padding: 0.75rem;
                border-radius: 10px;
                transition: all 0.3s ease;
                position: relative;
            }
            
            .member-item:hover {
                background: var(--light-gray);
            }
            
            .member-avatar {
                width: 40px;
                height: 40px;
                border-radius: 50%;
                background: var(--gradient-primary);
                display: flex;
                align-items: center;
                justify-content: center;
                color: white;
                font-family: 'Montserrat', sans-serif;
                font-weight: 600;
                font-size: 0.9rem;
            }
            
            .member-name {
                font-family: 'Montserrat', sans-serif;
                font-weight: 600;
                font-size: 0.9rem;
            }
            
            .member-role {
                font-family: 'Montserrat', sans-serif;
                font-size: 0.8rem;
                color: #6c757d;
            }
            
            .admin-crown {
                position: absolute;
                right: 1rem;
                color: #ffd700;
            }
            
            .group-actions {
                display: flex;
                gap: 0.5rem;
                flex-wrap: wrap;
                margin-top: 2rem;
            }
            
            .btn-danger {
                background: #dc3545;
                color: white;
                border: none;
                padding: 0.75rem 1.5rem;
                border-radius: 10px;
                font-family: 'Montserrat', sans-serif;
                font-weight: 600;
                cursor: pointer;
                transition: all 0.3s ease;
                display: flex;
                align-items: center;
                gap: 0.5rem;
            }
            
            .btn-danger:hover {
                background: #c82333;
                transform: translateY(-2px);
            }
        `;
        
        document.head.appendChild(style);
    }
}

// Initialiser les fonctionnalités avancées
let advancedFeatures;
document.addEventListener('DOMContentLoaded', () => {
    advancedFeatures = new AdvancedMessagingFeatures();
});

// Fonctions globales
function showScheduleMessage() {
    if (advancedFeatures) {
        advancedFeatures.showScheduleMessageModal();
    }
}

function showFavoriteMessages() {
    if (advancedFeatures) {
        advancedFeatures.showFavorites();
    }
}

function createNewGroup() {
    // Modal de création de groupe
    const modal = document.createElement('div');
    modal.className = 'modal-overlay';
    modal.innerHTML = `
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-users"></i> Créer un groupe</h3>
                <button class="modal-close" onclick="this.closest('.modal-overlay').remove()">×</button>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label>Nom du groupe</label>
                    <input type="text" class="form-input" placeholder="Ex: Aide Quartier Sud" id="groupName">
                </div>
                <div class="form-group">
                    <label>Description</label>
                    <textarea class="form-textarea" placeholder="Description du groupe..." id="groupDescription"></textarea>
                </div>
                <div class="form-group">
                    <label>Membres à ajouter</label>
                    <div class="users-list" id="groupMembersList">
                        <div class="user-item">
                            <input type="checkbox" id="member-marie" value="marie">
                            <label for="member-marie">
                                <div class="user-avatar">MD</div>
                                <div class="user-info">
                                    <div class="user-name">Marie Dupont</div>
                                    <div class="user-type">Senior</div>
                                </div>
                            </label>
                        </div>
                        <div class="user-item">
                            <input type="checkbox" id="member-jean" value="jean">
                            <label for="member-jean">
                                <div class="user-avatar">JP</div>
                                <div class="user-info">
                                    <div class="user-name">Jean Petit</div>
                                    <div class="user-type">Senior</div>
                                </div>
                            </label>
                        </div>
                        <div class="user-item">
                            <input type="checkbox" id="member-pierre" value="pierre">
                            <label for="member-pierre">
                                <div class="user-avatar">PM</div>
                                <div class="user-info">
                                    <div class="user-name">Pierre Martin</div>
                                    <div class="user-type">Senior</div>
                                </div>
                            </label>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn-secondary" onclick="this.closest('.modal-overlay').remove()">Annuler</button>
                <button class="btn-primary" onclick="confirmCreateGroup()">Créer le groupe</button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
}

function confirmCreateGroup() {
    const name = document.getElementById('groupName').value.trim();
    const description = document.getElementById('groupDescription').value.trim();
    const selectedMembers = Array.from(document.querySelectorAll('#groupMembersList input:checked'))
        .map(input => ({
            id: input.value,
            name: input.nextElementSibling.querySelector('.user-name').textContent,
            role: 'member'
        }));
    
    if (!name) {
        advancedFeatures.showNotification('Veuillez saisir un nom de groupe', 'error');
        return;
    }
    
    if (selectedMembers.length === 0) {
        advancedFeatures.showNotification('Veuillez sélectionner au moins un membre', 'error');
        return;
    }
    
    const groupId = advancedFeatures.createGroup(name, description, selectedMembers);
    document.querySelector('.modal-overlay').remove();
    
    advancedFeatures.showNotification('Groupe créé avec succès', 'success');
    
    // Sélectionner le nouveau groupe
    setTimeout(() => {
        advancedFeatures.selectGroupConversation(groupId);
    }, 500);
}
