// Fonctionnalités avancées : Messages vocaux et géolocalisation
class VoiceLocationFeatures {
    constructor() {
        this.mediaRecorder = null;
        this.audioChunks = [];
        this.isRecording = false;
        this.recordingStartTime = null;
        this.recordingTimer = null;
        this.map = null;
        
        this.initializeFeatures();
    }

    initializeFeatures() {
        this.setupVoiceRecording();
        this.setupGeolocation();
        this.setupAudioPlayer();
    }

    // === MESSAGES VOCAUX ===
    
    setupVoiceRecording() {
        // Vérifier le support du navigateur
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
            console.warn('Enregistrement vocal non supporté par ce navigateur');
            return;
        }

        // Ajouter les styles pour l'interface vocale
        this.addVoiceStyles();
    }

    async startVoiceRecording() {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ 
                audio: {
                    echoCancellation: true,
                    noiseSuppression: true,
                    sampleRate: 44100
                } 
            });
            
            this.mediaRecorder = new MediaRecorder(stream, {
                mimeType: 'audio/webm;codecs=opus'
            });
            
            this.audioChunks = [];
            this.isRecording = true;
            this.recordingStartTime = Date.now();
            
            this.mediaRecorder.ondataavailable = (event) => {
                if (event.data.size > 0) {
                    this.audioChunks.push(event.data);
                }
            };
            
            this.mediaRecorder.onstop = () => {
                this.processVoiceRecording();
            };
            
            this.mediaRecorder.start(100); // Collecter les données toutes les 100ms
            this.showRecordingInterface();
            this.startRecordingTimer();
            
        } catch (error) {
            console.error('Erreur lors de l\'accès au microphone:', error);
            this.showVoiceError('Impossible d\'accéder au microphone. Vérifiez les permissions.');
        }
    }

    stopVoiceRecording() {
        if (this.mediaRecorder && this.isRecording) {
            this.mediaRecorder.stop();
            this.mediaRecorder.stream.getTracks().forEach(track => track.stop());
            this.isRecording = false;
            this.hideRecordingInterface();
            this.stopRecordingTimer();
        }
    }

    processVoiceRecording() {
        const audioBlob = new Blob(this.audioChunks, { type: 'audio/webm' });
        const duration = Math.round((Date.now() - this.recordingStartTime) / 1000);
        
        if (duration < 1) {
            this.showVoiceError('Enregistrement trop court (minimum 1 seconde)');
            return;
        }
        
        if (duration > 300) { // 5 minutes max
            this.showVoiceError('Enregistrement trop long (maximum 5 minutes)');
            return;
        }

        const audioUrl = URL.createObjectURL(audioBlob);
        this.sendVoiceMessage(audioUrl, duration, audioBlob);
    }

    sendVoiceMessage(audioUrl, duration, audioBlob) {
        const message = {
            id: Date.now(),
            sender: 'me',
            content: '',
            time: 'Maintenant',
            read: false,
            reactions: [],
            voice: {
                url: audioUrl,
                duration: duration,
                blob: audioBlob,
                waveform: this.generateWaveform(duration)
            }
        };

        // Ajouter à la conversation
        if (window.conversations && window.currentConversation) {
            window.conversations[window.currentConversation].messages.push(message);
            
            const messageElement = this.createVoiceMessageElement(message);
            document.getElementById('messagesArea').appendChild(messageElement);
            
            // Scroll vers le bas
            const messagesArea = document.getElementById('messagesArea');
            messagesArea.scrollTop = messagesArea.scrollHeight;
        }
    }

    createVoiceMessageElement(message) {
        const messageDiv = document.createElement('div');
        messageDiv.className = 'message sent';
        messageDiv.dataset.messageId = message.id;

        const avatar = document.createElement('div');
        avatar.className = 'message-avatar';
        avatar.textContent = 'V';

        const content = document.createElement('div');
        content.className = 'message-content';

        const bubble = document.createElement('div');
        bubble.className = 'message-bubble voice-message';
        bubble.innerHTML = `
            <div class="voice-player">
                <button class="voice-play-btn" onclick="voiceFeatures.toggleVoicePlayback('${message.voice.url}', this)">
                    <i class="fas fa-play"></i>
                </button>
                <div class="voice-waveform">
                    ${message.voice.waveform}
                </div>
                <div class="voice-duration">${this.formatDuration(message.voice.duration)}</div>
            </div>
        `;

        const time = document.createElement('div');
        time.className = 'message-time';
        time.innerHTML = `
            ${message.time}
            <span class="read-status delivered">
                <i class="fas fa-check"></i>
                Livré
            </span>
        `;

        content.appendChild(bubble);
        content.appendChild(time);
        messageDiv.appendChild(avatar);
        messageDiv.appendChild(content);

        return messageDiv;
    }

    generateWaveform(duration) {
        // Générer une forme d'onde simulée
        const bars = Math.min(Math.max(duration * 2, 10), 50);
        let waveform = '';
        
        for (let i = 0; i < bars; i++) {
            const height = Math.random() * 80 + 20; // Entre 20% et 100%
            waveform += `<div class="waveform-bar" style="height: ${height}%"></div>`;
        }
        
        return waveform;
    }

    showRecordingInterface() {
        const recordingUI = document.createElement('div');
        recordingUI.id = 'voiceRecordingUI';
        recordingUI.className = 'voice-recording-ui';
        recordingUI.innerHTML = `
            <div class="recording-content">
                <div class="recording-animation">
                    <div class="recording-pulse"></div>
                    <i class="fas fa-microphone"></i>
                </div>
                <div class="recording-info">
                    <div class="recording-text">Enregistrement en cours...</div>
                    <div class="recording-timer">00:00</div>
                </div>
                <div class="recording-actions">
                    <button class="recording-cancel" onclick="voiceFeatures.cancelVoiceRecording()">
                        <i class="fas fa-times"></i>
                    </button>
                    <button class="recording-stop" onclick="voiceFeatures.stopVoiceRecording()">
                        <i class="fas fa-stop"></i>
                    </button>
                </div>
            </div>
        `;
        
        document.body.appendChild(recordingUI);
    }

    hideRecordingInterface() {
        const recordingUI = document.getElementById('voiceRecordingUI');
        if (recordingUI) {
            recordingUI.remove();
        }
    }

    startRecordingTimer() {
        this.recordingTimer = setInterval(() => {
            const elapsed = Math.floor((Date.now() - this.recordingStartTime) / 1000);
            const minutes = Math.floor(elapsed / 60);
            const seconds = elapsed % 60;
            const timerElement = document.querySelector('.recording-timer');
            if (timerElement) {
                timerElement.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
            }
            
            // Arrêter automatiquement après 5 minutes
            if (elapsed >= 300) {
                this.stopVoiceRecording();
            }
        }, 1000);
    }

    stopRecordingTimer() {
        if (this.recordingTimer) {
            clearInterval(this.recordingTimer);
            this.recordingTimer = null;
        }
    }

    cancelVoiceRecording() {
        if (this.mediaRecorder && this.isRecording) {
            this.mediaRecorder.stop();
            this.mediaRecorder.stream.getTracks().forEach(track => track.stop());
            this.isRecording = false;
        }
        this.hideRecordingInterface();
        this.stopRecordingTimer();
    }

    toggleVoicePlayback(audioUrl, button) {
        const audio = button.parentElement.querySelector('audio') || new Audio(audioUrl);
        
        if (audio.paused) {
            // Arrêter tous les autres audios
            document.querySelectorAll('.voice-player audio').forEach(a => {
                if (a !== audio) {
                    a.pause();
                    a.currentTime = 0;
                }
            });
            
            // Mettre à jour tous les boutons
            document.querySelectorAll('.voice-play-btn').forEach(btn => {
                btn.innerHTML = '<i class="fas fa-play"></i>';
            });
            
            audio.play();
            button.innerHTML = '<i class="fas fa-pause"></i>';
            
            audio.onended = () => {
                button.innerHTML = '<i class="fas fa-play"></i>';
            };
            
            if (!button.parentElement.querySelector('audio')) {
                button.parentElement.appendChild(audio);
            }
        } else {
            audio.pause();
            button.innerHTML = '<i class="fas fa-play"></i>';
        }
    }

    formatDuration(seconds) {
        const minutes = Math.floor(seconds / 60);
        const remainingSeconds = seconds % 60;
        return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
    }

    showVoiceError(message) {
        const errorDiv = document.createElement('div');
        errorDiv.className = 'voice-error';
        errorDiv.textContent = message;
        errorDiv.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: #ff4757;
            color: white;
            padding: 1rem 1.5rem;
            border-radius: 10px;
            z-index: 10000;
            font-family: 'Montserrat', sans-serif;
            box-shadow: 0 4px 20px rgba(0,0,0,0.15);
        `;
        
        document.body.appendChild(errorDiv);
        
        setTimeout(() => {
            errorDiv.remove();
        }, 5000);
    }

    // === GÉOLOCALISATION ===
    
    setupGeolocation() {
        if (!navigator.geolocation) {
            console.warn('Géolocalisation non supportée par ce navigateur');
            return;
        }
        
        this.addLocationStyles();
    }

    async shareLocation() {
        try {
            const position = await this.getCurrentPosition();
            const { latitude, longitude } = position.coords;
            
            // Obtenir l'adresse via reverse geocoding
            const address = await this.reverseGeocode(latitude, longitude);
            
            const message = {
                id: Date.now(),
                sender: 'me',
                content: '',
                time: 'Maintenant',
                read: false,
                reactions: [],
                location: {
                    latitude: latitude,
                    longitude: longitude,
                    address: address,
                    accuracy: position.coords.accuracy
                }
            };

            // Ajouter à la conversation
            if (window.conversations && window.currentConversation) {
                window.conversations[window.currentConversation].messages.push(message);
                
                const messageElement = this.createLocationMessageElement(message);
                document.getElementById('messagesArea').appendChild(messageElement);
                
                // Scroll vers le bas
                const messagesArea = document.getElementById('messagesArea');
                messagesArea.scrollTop = messagesArea.scrollHeight;
            }
            
        } catch (error) {
            console.error('Erreur de géolocalisation:', error);
            this.showLocationError('Impossible d\'obtenir votre position. Vérifiez les permissions.');
        }
    }

    getCurrentPosition() {
        return new Promise((resolve, reject) => {
            navigator.geolocation.getCurrentPosition(
                resolve,
                reject,
                {
                    enableHighAccuracy: true,
                    timeout: 10000,
                    maximumAge: 300000 // 5 minutes
                }
            );
        });
    }

    async reverseGeocode(lat, lon) {
        try {
            const response = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lon}&zoom=18&addressdetails=1`);
            const data = await response.json();
            
            if (data.display_name) {
                return data.display_name;
            } else {
                return `${lat.toFixed(6)}, ${lon.toFixed(6)}`;
            }
        } catch (error) {
            console.error('Erreur de géocodage inverse:', error);
            return `${lat.toFixed(6)}, ${lon.toFixed(6)}`;
        }
    }

    createLocationMessageElement(message) {
        const messageDiv = document.createElement('div');
        messageDiv.className = 'message sent';
        messageDiv.dataset.messageId = message.id;

        const avatar = document.createElement('div');
        avatar.className = 'message-avatar';
        avatar.textContent = 'V';

        const content = document.createElement('div');
        content.className = 'message-content';

        const bubble = document.createElement('div');
        bubble.className = 'message-bubble location-message';
        bubble.innerHTML = `
            <div class="location-content">
                <div class="location-header">
                    <i class="fas fa-map-marker-alt"></i>
                    <span>Position partagée</span>
                </div>
                <div class="location-map" id="map-${message.id}"></div>
                <div class="location-info">
                    <div class="location-address">${message.location.address}</div>
                    <div class="location-coords">
                        ${message.location.latitude.toFixed(6)}, ${message.location.longitude.toFixed(6)}
                    </div>
                    <div class="location-accuracy">
                        Précision: ±${Math.round(message.location.accuracy)}m
                    </div>
                </div>
                <div class="location-actions">
                    <button class="location-btn" onclick="voiceFeatures.openInMaps(${message.location.latitude}, ${message.location.longitude})">
                        <i class="fas fa-external-link-alt"></i> Ouvrir dans Maps
                    </button>
                    <button class="location-btn" onclick="voiceFeatures.getDirections(${message.location.latitude}, ${message.location.longitude})">
                        <i class="fas fa-route"></i> Itinéraire
                    </button>
                </div>
            </div>
        `;

        const time = document.createElement('div');
        time.className = 'message-time';
        time.innerHTML = `
            ${message.time}
            <span class="read-status delivered">
                <i class="fas fa-check"></i>
                Livré
            </span>
        `;

        content.appendChild(bubble);
        content.appendChild(time);
        messageDiv.appendChild(avatar);
        messageDiv.appendChild(content);

        // Initialiser la carte après l'ajout au DOM
        setTimeout(() => {
            this.initializeLocationMap(message.id, message.location.latitude, message.location.longitude);
        }, 100);

        return messageDiv;
    }

    initializeLocationMap(messageId, lat, lon) {
        const mapContainer = document.getElementById(`map-${messageId}`);
        if (!mapContainer) return;

        // Utiliser Leaflet pour la carte
        if (typeof L !== 'undefined') {
            const map = L.map(mapContainer, {
                zoomControl: false,
                attributionControl: false,
                dragging: false,
                touchZoom: false,
                doubleClickZoom: false,
                scrollWheelZoom: false,
                boxZoom: false,
                keyboard: false
            }).setView([lat, lon], 15);

            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(map);
            
            L.marker([lat, lon]).addTo(map)
                .bindPopup('Position partagée')
                .openPopup();
        } else {
            // Fallback avec image statique
            mapContainer.innerHTML = `
                <img src="https://api.mapbox.com/styles/v1/mapbox/streets-v11/static/pin-s+ff0000(${lon},${lat})/${lon},${lat},15,0/300x200?access_token=pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpejY4NXVycTA2emYycXBndHRqcmZ3N3gifQ.rJcFIG214AriISLbB6B5aw" 
                     alt="Carte de localisation" style="width: 100%; height: 100%; object-fit: cover; border-radius: 10px;">
            `;
        }
    }

    openInMaps(lat, lon) {
        const isMobile = /Android|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
        
        if (isMobile) {
            // Ouvrir dans l'app native
            window.open(`geo:${lat},${lon}?q=${lat},${lon}`);
        } else {
            // Ouvrir dans Google Maps web
            window.open(`https://www.google.com/maps?q=${lat},${lon}`, '_blank');
        }
    }

    getDirections(lat, lon) {
        const isMobile = /Android|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
        
        if (isMobile) {
            window.open(`geo:0,0?q=${lat},${lon}`);
        } else {
            window.open(`https://www.google.com/maps/dir/?api=1&destination=${lat},${lon}`, '_blank');
        }
    }

    showLocationError(message) {
        const errorDiv = document.createElement('div');
        errorDiv.className = 'location-error';
        errorDiv.textContent = message;
        errorDiv.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: #ff4757;
            color: white;
            padding: 1rem 1.5rem;
            border-radius: 10px;
            z-index: 10000;
            font-family: 'Montserrat', sans-serif;
            box-shadow: 0 4px 20px rgba(0,0,0,0.15);
        `;
        
        document.body.appendChild(errorDiv);
        
        setTimeout(() => {
            errorDiv.remove();
        }, 5000);
    }

    // === STYLES ===
    
    addVoiceStyles() {
        const style = document.createElement('style');
        style.textContent = `
            .voice-message {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important;
                color: white !important;
            }
            
            .voice-player {
                display: flex;
                align-items: center;
                gap: 1rem;
                padding: 0.5rem;
            }
            
            .voice-play-btn {
                background: rgba(255,255,255,0.2);
                border: none;
                border-radius: 50%;
                width: 40px;
                height: 40px;
                display: flex;
                align-items: center;
                justify-content: center;
                color: white;
                cursor: pointer;
                transition: all 0.3s ease;
            }
            
            .voice-play-btn:hover {
                background: rgba(255,255,255,0.3);
                transform: scale(1.1);
            }
            
            .voice-waveform {
                flex: 1;
                display: flex;
                align-items: center;
                gap: 2px;
                height: 30px;
            }
            
            .waveform-bar {
                background: rgba(255,255,255,0.7);
                width: 3px;
                border-radius: 2px;
                transition: all 0.3s ease;
            }
            
            .voice-duration {
                font-size: 0.8rem;
                color: rgba(255,255,255,0.8);
                font-family: 'Montserrat', sans-serif;
                font-weight: 500;
            }
            
            .voice-recording-ui {
                position: fixed;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background: rgba(0,0,0,0.8);
                display: flex;
                align-items: center;
                justify-content: center;
                z-index: 10000;
            }
            
            .recording-content {
                background: white;
                border-radius: 20px;
                padding: 3rem;
                text-align: center;
                box-shadow: 0 10px 40px rgba(0,0,0,0.3);
                max-width: 400px;
                width: 90%;
            }
            
            .recording-animation {
                position: relative;
                margin-bottom: 2rem;
            }
            
            .recording-pulse {
                position: absolute;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                width: 100px;
                height: 100px;
                border-radius: 50%;
                background: #ff4757;
                animation: pulse 2s infinite;
                opacity: 0.3;
            }
            
            @keyframes pulse {
                0% { transform: translate(-50%, -50%) scale(1); opacity: 0.3; }
                50% { transform: translate(-50%, -50%) scale(1.2); opacity: 0.1; }
                100% { transform: translate(-50%, -50%) scale(1); opacity: 0.3; }
            }
            
            .recording-animation i {
                font-size: 3rem;
                color: #ff4757;
                position: relative;
                z-index: 1;
            }
            
            .recording-info {
                margin-bottom: 2rem;
            }
            
            .recording-text {
                font-family: 'Montserrat', sans-serif;
                font-size: 1.2rem;
                font-weight: 600;
                color: #333;
                margin-bottom: 0.5rem;
            }
            
            .recording-timer {
                font-family: 'Montserrat', sans-serif;
                font-size: 2rem;
                font-weight: 700;
                color: #ff4757;
            }
            
            .recording-actions {
                display: flex;
                gap: 1rem;
                justify-content: center;
            }
            
            .recording-cancel,
            .recording-stop {
                background: none;
                border: 2px solid;
                border-radius: 50%;
                width: 60px;
                height: 60px;
                display: flex;
                align-items: center;
                justify-content: center;
                cursor: pointer;
                transition: all 0.3s ease;
                font-size: 1.5rem;
            }
            
            .recording-cancel {
                border-color: #6c757d;
                color: #6c757d;
            }
            
            .recording-cancel:hover {
                background: #6c757d;
                color: white;
            }
            
            .recording-stop {
                border-color: #ff4757;
                color: #ff4757;
            }
            
            .recording-stop:hover {
                background: #ff4757;
                color: white;
            }
        `;
        
        document.head.appendChild(style);
    }
    
    addLocationStyles() {
        const style = document.createElement('style');
        style.textContent = `
            .location-message {
                background: linear-gradient(135deg, #56ab2f 0%, #a8e6cf 100%) !important;
                color: white !important;
                padding: 0 !important;
                overflow: hidden;
            }
            
            .location-content {
                width: 100%;
            }
            
            .location-header {
                display: flex;
                align-items: center;
                gap: 0.5rem;
                padding: 1rem;
                background: rgba(0,0,0,0.1);
                font-family: 'Montserrat', sans-serif;
                font-weight: 600;
            }
            
            .location-map {
                width: 100%;
                height: 200px;
                background: #f0f0f0;
                position: relative;
            }
            
            .location-info {
                padding: 1rem;
            }
            
            .location-address {
                font-family: 'Montserrat', sans-serif;
                font-weight: 600;
                font-size: 0.9rem;
                margin-bottom: 0.5rem;
            }
            
            .location-coords {
                font-family: 'Montserrat', sans-serif;
                font-size: 0.8rem;
                opacity: 0.8;
                margin-bottom: 0.25rem;
            }
            
            .location-accuracy {
                font-family: 'Montserrat', sans-serif;
                font-size: 0.75rem;
                opacity: 0.7;
            }
            
            .location-actions {
                display: flex;
                gap: 0.5rem;
                padding: 0 1rem 1rem 1rem;
            }
            
            .location-btn {
                background: rgba(255,255,255,0.2);
                border: 1px solid rgba(255,255,255,0.3);
                color: white;
                padding: 0.5rem 1rem;
                border-radius: 20px;
                font-family: 'Montserrat', sans-serif;
                font-size: 0.8rem;
                cursor: pointer;
                transition: all 0.3s ease;
                display: flex;
                align-items: center;
                gap: 0.5rem;
            }
            
            .location-btn:hover {
                background: rgba(255,255,255,0.3);
                transform: translateY(-2px);
            }
        `;
        
        document.head.appendChild(style);
    }

    setupAudioPlayer() {
        // Configuration globale pour les lecteurs audio
        document.addEventListener('play', (e) => {
            if (e.target.tagName === 'AUDIO') {
                // Pause tous les autres audios
                document.querySelectorAll('audio').forEach(audio => {
                    if (audio !== e.target) {
                        audio.pause();
                    }
                });
            }
        }, true);
    }
}

// Initialiser les fonctionnalités
let voiceFeatures;
document.addEventListener('DOMContentLoaded', () => {
    voiceFeatures = new VoiceLocationFeatures();
});

// Fonctions globales pour l'interface
function startVoiceMessage() {
    if (voiceFeatures) {
        voiceFeatures.startVoiceRecording();
    }
}

function shareCurrentLocation() {
    if (voiceFeatures) {
        voiceFeatures.shareLocation();
    }
}
