// ===== NAVIGATION RESPONSIVE COMPLÈTE ===== 

class ResponsiveNavComplete {
    constructor() {
        this.burgerMenu = null;
        this.navMobile = null;
        this.overlay = null;
        this.isMenuOpen = false;
        this.currentUser = null;
        this.userType = 'senior';
        
        this.init();
    }

    init() {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => this.setup());
        } else {
            this.setup();
        }
    }

    setup() {
        this.createNavigation();
        this.setupEventListeners();
        this.loadCurrentUser();
        this.setActivePage();
    }

    createNavigation() {
        // Supprimer les anciennes navigations
        const oldNavs = document.querySelectorAll('.navbar-ultra, .responsive-navbar, .sidebar-ultra');
        oldNavs.forEach(nav => nav.remove());

        // Créer le header responsive
        const header = document.createElement('header');
        header.className = 'header-responsive';
        header.innerHTML = `
            <a href="index.html" class="logo-responsive">
                <img src="logo.png" alt="Assembl'âge">
                <span>Assembl'âge</span>
            </a>
            
            <nav class="nav-desktop">
                <li><a href="dashboard.html" data-page="dashboard">
                    <i class="fas fa-tachometer-alt"></i>
                    Tableau de bord
                </a></li>
                <li><a href="help-requests.html" data-page="requests" id="nav-requests">
                    <i class="fas fa-hands-helping"></i>
                    <span id="nav-requests-text">Mes demandes</span>
                </a></li>
                <li><a href="messages.html" data-page="messages">
                    <i class="fas fa-envelope"></i>
                    Messages
                    <span class="nav-badge" id="nav-message-count">0</span>
                </a></li>
                <li><a href="profile.html" data-page="profile">
                    <i class="fas fa-user"></i>
                    Mon profil
                </a></li>
                <li><a href="#" onclick="logout()">
                    <i class="fas fa-sign-out-alt"></i>
                    Déconnexion
                </a></li>
            </nav>
            
            <button class="burger-menu" id="burgerMenu">
                <div class="burger-line"></div>
                <div class="burger-line"></div>
                <div class="burger-line"></div>
            </button>
        `;

        // Créer le menu mobile
        const navMobile = document.createElement('nav');
        navMobile.className = 'nav-mobile';
        navMobile.id = 'navMobile';
        navMobile.innerHTML = `
            <ul>
                <li><a href="dashboard.html" data-page="dashboard">
                    <i class="fas fa-tachometer-alt nav-mobile-icon"></i>
                    Tableau de bord
                </a></li>
                <li><a href="help-requests.html" data-page="requests" id="mobile-nav-requests">
                    <i class="fas fa-hands-helping nav-mobile-icon"></i>
                    <span id="mobile-nav-requests-text">Mes demandes</span>
                </a></li>
                <li><a href="messages.html" data-page="messages">
                    <i class="fas fa-envelope nav-mobile-icon"></i>
                    Messages
                    <span class="nav-badge" id="mobile-message-count">0</span>
                </a></li>
                <li><a href="profile.html" data-page="profile">
                    <i class="fas fa-user nav-mobile-icon"></i>
                    Mon profil
                </a></li>
                <li><a href="search-simple.html" data-page="search">
                    <i class="fas fa-search nav-mobile-icon"></i>
                    Recherche
                </a></li>
                <li><a href="#" onclick="contactAdmin()">
                    <i class="fas fa-headset nav-mobile-icon"></i>
                    Contact admin
                </a></li>
                <li><a href="#" onclick="logout()">
                    <i class="fas fa-sign-out-alt nav-mobile-icon"></i>
                    Déconnexion
                </a></li>
            </ul>
        `;

        // Créer l'overlay
        const overlay = document.createElement('div');
        overlay.className = 'overlay-mobile';
        overlay.id = 'overlayMobile';

        // Insérer au début du body
        document.body.insertBefore(header, document.body.firstChild);
        document.body.insertBefore(navMobile, document.body.firstChild.nextSibling);
        document.body.insertBefore(overlay, document.body.firstChild.nextSibling.nextSibling);

        // Adapter le contenu principal
        this.adaptMainContent();
        
        // Récupérer les références
        this.burgerMenu = document.getElementById('burgerMenu');
        this.navMobile = document.getElementById('navMobile');
        this.overlay = document.getElementById('overlayMobile');
    }

    adaptMainContent() {
        // Trouver le contenu principal
        let mainContent = document.querySelector('main, .main-content, #mainContent');
        
        if (!mainContent) {
            // Créer un wrapper pour le contenu existant
            const bodyContent = Array.from(document.body.children).filter(child => 
                !child.classList.contains('header-responsive') && 
                !child.classList.contains('nav-mobile') && 
                !child.classList.contains('overlay-mobile')
            );
            
            if (bodyContent.length > 0) {
                mainContent = document.createElement('main');
                mainContent.className = 'main-responsive';
                
                bodyContent.forEach(element => {
                    mainContent.appendChild(element);
                });
                
                document.body.appendChild(mainContent);
            }
        } else {
            // Adapter le contenu existant
            mainContent.className = 'main-responsive';
        }

        // Ajouter un container si nécessaire
        if (mainContent && !mainContent.querySelector('.container-responsive')) {
            const container = document.createElement('div');
            container.className = 'container-responsive';
            
            while (mainContent.firstChild) {
                container.appendChild(mainContent.firstChild);
            }
            
            mainContent.appendChild(container);
        }
    }

    setupEventListeners() {
        // Burger menu toggle
        if (this.burgerMenu) {
            this.burgerMenu.addEventListener('click', (e) => {
                e.preventDefault();
                this.toggleMobileMenu();
            });
        }

        // Overlay click
        if (this.overlay) {
            this.overlay.addEventListener('click', () => {
                this.closeMobileMenu();
            });
        }

        // Fermer le menu sur les liens
        const mobileLinks = document.querySelectorAll('.nav-mobile a');
        mobileLinks.forEach(link => {
            link.addEventListener('click', () => {
                if (!link.getAttribute('href').startsWith('#')) {
                    this.closeMobileMenu();
                }
            });
        });

        // Resize handler
        window.addEventListener('resize', () => {
            if (window.innerWidth > 768 && this.isMenuOpen) {
                this.closeMobileMenu();
            }
        });

        // Escape key
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && this.isMenuOpen) {
                this.closeMobileMenu();
            }
        });
    }

    toggleMobileMenu() {
        if (this.isMenuOpen) {
            this.closeMobileMenu();
        } else {
            this.openMobileMenu();
        }
    }

    openMobileMenu() {
        this.isMenuOpen = true;
        this.burgerMenu?.classList.add('active');
        this.navMobile?.classList.add('show');
        this.overlay?.classList.add('show');
        document.body.style.overflow = 'hidden';
    }

    closeMobileMenu() {
        this.isMenuOpen = false;
        this.burgerMenu?.classList.remove('active');
        this.navMobile?.classList.remove('show');
        this.overlay?.classList.remove('show');
        document.body.style.overflow = '';
    }

    setActivePage() {
        const currentPage = this.getCurrentPage();
        
        // Retirer toutes les classes active
        document.querySelectorAll('.nav-desktop a, .nav-mobile a').forEach(link => {
            link.classList.remove('active');
        });

        // Ajouter la classe active aux liens correspondants
        document.querySelectorAll(`[data-page="${currentPage}"]`).forEach(link => {
            link.classList.add('active');
        });
    }

    getCurrentPage() {
        const path = window.location.pathname;
        const filename = path.split('/').pop().split('.')[0];
        
        const pageMap = {
            'dashboard': 'dashboard',
            'help-requests': 'requests',
            'my-service-offers': 'requests',
            'messages': 'messages',
            'profile': 'profile',
            'profile-aidant-complet': 'profile',
            'profile-senior-complet': 'profile',
            'search-simple': 'search',
            'search-geolocalized': 'search'
        };

        return pageMap[filename] || 'dashboard';
    }

    async loadCurrentUser() {
        try {
            const response = await fetch('/api/auth/current-user');
            const data = await response.json();
            
            if (data.success && data.user) {
                this.currentUser = data.user;
                this.userType = data.user.user_type || 'senior';
                this.adaptNavigationForUserType();
                this.updateMessageCount();
            }
        } catch (error) {
            console.error('Erreur lors du chargement de l\'utilisateur:', error);
            this.userType = localStorage.getItem('userType') || 'senior';
            this.adaptNavigationForUserType();
        }
    }

    adaptNavigationForUserType() {
        const elements = {
            navRequestsText: document.getElementById('nav-requests-text'),
            mobileNavRequestsText: document.getElementById('mobile-nav-requests-text'),
            navRequests: document.getElementById('nav-requests'),
            mobileNavRequests: document.getElementById('mobile-nav-requests')
        };

        if (this.userType === 'aidant') {
            if (elements.navRequestsText) elements.navRequestsText.textContent = 'Mes offres';
            if (elements.mobileNavRequestsText) elements.mobileNavRequestsText.textContent = 'Mes offres';
            if (elements.navRequests) elements.navRequests.href = 'my-service-offers.html';
            if (elements.mobileNavRequests) elements.mobileNavRequests.href = 'my-service-offers.html';
        } else {
            if (elements.navRequestsText) elements.navRequestsText.textContent = 'Mes demandes';
            if (elements.mobileNavRequestsText) elements.mobileNavRequestsText.textContent = 'Mes demandes';
            if (elements.navRequests) elements.navRequests.href = 'help-requests.html';
            if (elements.mobileNavRequests) elements.mobileNavRequests.href = 'help-requests.html';
        }
    }

    async updateMessageCount() {
        try {
            const response = await fetch('/api/messages/count');
            const data = await response.json();
            
            if (data.success) {
                const count = data.count || 0;
                const badges = document.querySelectorAll('#nav-message-count, #mobile-message-count');
                badges.forEach(badge => {
                    badge.textContent = count;
                    badge.style.display = count > 0 ? 'inline' : 'none';
                });
            }
        } catch (error) {
            console.error('Erreur lors du chargement du nombre de messages:', error);
        }
    }
}

// Fonctions globales
function logout() {
    if (confirm('Êtes-vous sûr de vouloir vous déconnecter ?')) {
        fetch('/api/auth/logout', { method: 'POST' })
            .then(() => {
                localStorage.clear();
                window.location.href = '/';
            })
            .catch(() => {
                window.location.href = '/';
            });
    }
}

function contactAdmin() {
    window.location.href = 'mailto:admin@assemblage.com';
}

// Initialiser la navigation responsive complète
const responsiveNavComplete = new ResponsiveNavComplete();

// Export pour utilisation dans d'autres scripts
if (typeof module !== 'undefined' && module.exports) {
    module.exports = ResponsiveNavComplete;
}

