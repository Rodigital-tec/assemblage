// Système de Modération Utilisateur - Assembl'âge
// Fonctionnalités de signalement et de blocage

// Configuration API
const API_BASE_URL = window.API
