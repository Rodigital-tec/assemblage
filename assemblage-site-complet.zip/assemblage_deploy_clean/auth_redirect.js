/**
 * Système de gestion des redirections et états utilisateur
 * Gère la redirection automatique des utilisateurs connectés
 */

class AuthRedirectManager {
    constructor() {
        this.currentPage = this.getCurrentPageName();
        this.publicPages = ['index.html', 'login.html', ''];
        this.protectedPages = ['dashboard.html', 'profile.html', 'messages.html', 'my-service-offers.html', 'help-requests.html'];
        this.init();
    }

    getCurrentPageName() {
        const path = window.location.pathname;
        const fileName = path.split('/').pop() || 'index.html';
        return fileName;
    }

    async init() {
        await this.checkAuthAndRedirect();
    }

    async checkAuthAndRedirect() {
        try {
            const response = await fetch('/api/auth/check-auth');
            let isAuthenticated = false;
            let userData = null;

            if (response.ok) {
                const data = await response.json();
                isAuthenticated = data.authenticated || false;
                userData = data.user;
            } else {
                // Fallback sur localStorage
                isAuthenticated = localStorage.getItem('isAuthenticated') === 'true';
            }

            // Gérer les redirections selon l'état et la page
            this.handleRedirection(isAuthenticated, userData);

        } catch (error) {
            console.log('Erreur lors de la vérification d\'authentification:', error);
            // Fallback sur localStorage
            const isAuthenticated = localStorage.getItem('isAuthenticated') === 'true';
            this.handleRedirection(isAuthenticated, null);
        }
    }

    handleRedirection(isAuthenticated, userData) {
        if (isAuthenticated) {
            // Utilisateur connecté
            this.handleAuthenticatedUser(userData);
        } else {
            // Utilisateur non connecté
            this.handleUnauthenticatedUser();
        }
    }

    handleAuthenticatedUser(userData) {
        // Si l'utilisateur est sur une page publique (sauf login), le rediriger vers le dashboard
        if (this.publicPages.includes(this.currentPage) && this.currentPage !== 'login.html') {
            // Sauvegarder la page d'origine si elle n'est pas l'accueil
            if (this.currentPage !== 'index.html' && this.currentPage !== '') {
                localStorage.setItem('redirectAfterLogin', this.currentPage);
            }
            
            // Redirection avec un petit délai pour éviter les conflits
            setTimeout(() => {
                window.location.href = 'dashboard.html';
            }, 100);
            return;
        }

        // Si l'utilisateur est sur la page de login, le rediriger vers sa destination
        if (this.currentPage === 'login.html') {
            const redirectTo = localStorage.getItem('redirectAfterLogin') || 'dashboard.html';
            localStorage.removeItem('redirectAfterLogin');
            
            setTimeout(() => {
                window.location.href = redirectTo;
            }, 100);
            return;
        }
    }

    handleUnauthenticatedUser() {
        // Si l'utilisateur non connecté tente d'accéder à une page protégée
        if (this.protectedPages.includes(this.currentPage)) {
            // Sauvegarder la page demandée pour redirection après connexion
            localStorage.setItem('redirectAfterLogin', this.currentPage);
            
            // Rediriger vers la page de connexion
            setTimeout(() => {
                window.location.href = 'login.html';
            }, 100);
            return;
        }
    }

    // Méthode pour forcer une redirection après connexion
    static redirectAfterLogin() {
        const redirectTo = localStorage.getItem('redirectAfterLogin') || 'dashboard.html';
        localStorage.removeItem('redirectAfterLogin');
        window.location.href = redirectTo;
    }

    // Méthode pour sauvegarder une destination de redirection
    static setRedirectDestination(destination) {
        localStorage.setItem('redirectAfterLogin', destination);
    }
}

// Système de notification pour les redirections
class RedirectNotification {
    static show(message, type = 'info') {
        // Créer une notification temporaire
        const notification = document.createElement('div');
        notification.className = `redirect-notification ${type}`;
        notification.textContent = message;
        
        // Styles inline pour la notification
        Object.assign(notification.style, {
            position: 'fixed',
            top: '20px',
            right: '20px',
            padding: '12px 20px',
            backgroundColor: type === 'info' ? '#4CAF50' : '#f44336',
            color: 'white',
            borderRadius: '4px',
            zIndex: '10000',
            fontSize: '14px',
            boxShadow: '0 2px 8px rgba(0,0,0,0.2)',
            transition: 'all 0.3s ease'
        });

        document.body.appendChild(notification);

        // Supprimer après 3 secondes
        setTimeout(() => {
            notification.style.opacity = '0';
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 300);
        }, 3000);
    }
}

// Initialiser le gestionnaire de redirection
document.addEventListener('DOMContentLoaded', () => {
    new AuthRedirectManager();
});

// Exporter pour utilisation globale
window.AuthRedirectManager = AuthRedirectManager;
window.RedirectNotification = RedirectNotification;
