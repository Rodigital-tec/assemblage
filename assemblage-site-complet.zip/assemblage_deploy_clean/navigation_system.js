// ===== SYSTÈME DE NAVIGATION DIFFÉRENCIÉ =====

class NavigationSystem {
    constructor() {
        this.currentPage = window.location.pathname.split('/').pop() || 'index.html';
        this.userType = localStorage.getItem('userType');
        this.userName = localStorage.getItem('userName');
        this.isAuthenticated = false;
        
        this.init();
    }

    async init() {
        // Vérifier l'authentification
        await this.checkAuthentication();
        
        // Créer la navigation appropriée
        this.createNavigation();
        
        // Initialiser les événements
        this.initEvents();
    }

    async checkAuthentication() {
        try {
            const response = await fetch('/api/auth/check-auth');
            
            if (response.ok) {
                const data = await response.json();
                
                if (data.authenticated && data.user) {
                    this.isAuthenticated = true;
                    this.userType = data.user.user_type;
                    this.userName = data.user.first_name;
                    
                    // Mettre à jour le localStorage
                    localStorage.setItem('userType', data.user.user_type);
                    localStorage.setItem('userName', data.user.first_name);
                    localStorage.setItem('userEmail', data.user.email);
                    
                    console.log('Utilisateur authentifié:', data.user.user_type);
                    return;
                }
            }
            
            // Si on arrive ici, l'utilisateur n'est pas authentifié
            this.isAuthenticated = false;
            this.userType = null;
            this.userName = null;
            
            // Nettoyer le localStorage
            localStorage.removeItem('userType');
            localStorage.removeItem('userName');
            localStorage.removeItem('userEmail');
            
            console.log('Utilisateur non authentifié');
            
        } catch (error) {
            console.log('Erreur lors de la vérification d\'authentification:', error);
            this.isAuthenticated = false;
            this.userType = null;
            this.userName = null;
            
            // Nettoyer le localStorage en cas d'erreur
            localStorage.removeItem('userType');
            localStorage.removeItem('userName');
            localStorage.removeItem('userEmail');
        }
    }

    createNavigation() {
        // Supprimer toute navigation existante
        const existingHeaders = document.querySelectorAll('header, .header-public, .header-authenticated');
        existingHeaders.forEach(header => header.remove());
        
        const existingMenus = document.querySelectorAll('.mobile-menu, .mobile-overlay');
        existingMenus.forEach(menu => menu.remove());

        console.log('Création navigation - Authentifié:', this.isAuthenticated, 'Type:', this.userType);

        if (this.isAuthenticated && this.userType) {
            console.log('Création header authentifié');
            this.createAuthenticatedHeader();
        } else {
            console.log('Création header public');
            this.createPublicHeader();
        }
    }

    createPublicHeader() {
        const header = document.createElement('header');
        header.className = 'header-public';
        
        header.innerHTML = `
            <a href="index.html" class="logo">
                <div class="logo-icon">A</div>
                <span>Assembl'âge</span>
            </a>
            
            <nav class="nav-public">
                <a href="index.html#services" class="nav-link">Services</a>
                <a href="index.html#comment-ca-marche" class="nav-link">Comment ça marche</a>
                <a href="login.html" class="btn-login">
                    <i class="fas fa-sign-in-alt"></i>
                    Se connecter
                </a>
            </nav>
            
            <div class="mobile-menu-toggle" onclick="navigationSystem.toggleMobileMenu()">
                <span></span>
                <span></span>
                <span></span>
            </div>
        `;

        // Menu mobile pour page publique
        const mobileMenu = document.createElement('div');
        mobileMenu.className = 'mobile-menu';
        mobileMenu.innerHTML = `
            <a href="index.html#services" class="nav-link">
                <i class="fas fa-cogs"></i>
                Services
            </a>
            <a href="index.html#comment-ca-marche" class="nav-link">
                <i class="fas fa-question-circle"></i>
                Comment ça marche
            </a>
            <a href="login.html" class="nav-link">
                <i class="fas fa-sign-in-alt"></i>
                Se connecter
            </a>
        `;

        document.body.insertBefore(header, document.body.firstChild);
        document.body.appendChild(mobileMenu);
        this.createMobileOverlay();
    }

    createAuthenticatedHeader() {
        const header = document.createElement('header');
        header.className = 'header-authenticated';
        
        // Navigation adaptée selon le type d'utilisateur
        const navItems = this.getNavigationItems();
        
        header.innerHTML = `
            <a href="dashboard.html" class="logo">
                <div class="logo-icon">A</div>
                <span>Assembl'âge</span>
            </a>
            
            <nav class="nav-authenticated">
                ${navItems.map(item => `
                    <div class="nav-item">
                        <a href="${item.href}" class="nav-link ${this.isActivePage(item.href) ? 'active' : ''}">
                            <i class="${item.icon}"></i>
                            <span>${item.text}</span>
                            ${item.badge ? `<span class="badge">${item.badge}</span>` : ''}
                        </a>
                    </div>
                `).join('')}
            </nav>
            
            <div class="mobile-menu-toggle" onclick="navigationSystem.toggleMobileMenu()">
                <span></span>
                <span></span>
                <span></span>
            </div>
        `;

        // Menu mobile pour utilisateurs connectés
        const mobileMenu = document.createElement('div');
        mobileMenu.className = 'mobile-menu';
        mobileMenu.innerHTML = navItems.map(item => `
            <a href="${item.href}" class="nav-link ${this.isActivePage(item.href) ? 'active' : ''}">
                <i class="${item.icon}"></i>
                <span>${item.text}</span>
                ${item.badge ? `<span class="badge">${item.badge}</span>` : ''}
            </a>
        `).join('');

        document.body.insertBefore(header, document.body.firstChild);
        document.body.appendChild(mobileMenu);
        this.createMobileOverlay();
    }

    getNavigationItems() {
        const baseItems = [
            {
                href: 'dashboard.html',
                icon: 'fas fa-tachometer-alt',
                text: 'Tableau de bord'
            }
        ];

        // Navigation spécifique selon le type d'utilisateur
        if (this.userType === 'aidant') {
            baseItems.push(
                {
                    href: 'my-service-offers.html',
                    icon: 'fas fa-briefcase',
                    text: 'Mes offres'
                },
                {
                    href: 'search-simple.html',
                    icon: 'fas fa-search',
                    text: 'Rechercher'
                }
            );
        } else if (this.userType === 'senior') {
            baseItems.push(
                {
                    href: 'help-requests.html',
                    icon: 'fas fa-hand-holding-heart',
                    text: 'Mes demandes'
                },
                {
                    href: 'search-simple.html',
                    icon: 'fas fa-search',
                    text: 'Rechercher'
                }
            );
        } else if (this.userType === 'admin') {
            baseItems.push(
                {
                    href: 'admin.html',
                    icon: 'fas fa-cog',
                    text: 'Administration'
                }
            );
        }

        // Items communs
        baseItems.push(
            {
                href: 'messages.html',
                icon: 'fas fa-envelope',
                text: 'Messages',
                badge: '0'
            },
            {
                href: 'profile.html',
                icon: 'fas fa-user',
                text: 'Mon profil'
            },
            {
                href: '#',
                icon: 'fas fa-sign-out-alt',
                text: 'Déconnexion',
                onclick: 'navigationSystem.logout()'
            }
        );

        return baseItems;
    }

    isActivePage(href) {
        if (href === '#') return false;
        const pageName = href.split('/').pop();
        return this.currentPage === pageName;
    }

    createMobileOverlay() {
        const overlay = document.createElement('div');
        overlay.className = 'mobile-overlay';
        overlay.onclick = () => this.closeMobileMenu();
        document.body.appendChild(overlay);
    }

    toggleMobileMenu() {
        const toggle = document.querySelector('.mobile-menu-toggle');
        const menu = document.querySelector('.mobile-menu');
        const overlay = document.querySelector('.mobile-overlay');
        
        toggle.classList.toggle('active');
        menu.classList.toggle('active');
        overlay.classList.toggle('active');
    }

    closeMobileMenu() {
        const toggle = document.querySelector('.mobile-menu-toggle');
        const menu = document.querySelector('.mobile-menu');
        const overlay = document.querySelector('.mobile-overlay');
        
        toggle.classList.remove('active');
        menu.classList.remove('active');
        overlay.classList.remove('active');
    }

      async logout() {
        try {
            const response = await fetch('/api/auth/logout', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                }
            });
            
            if (response.ok) {
                // Nettoyer le localStorage
                localStorage.clear();
                sessionStorage.clear();
                
                // Forcer la mise à jour de l'état d'authentification
                this.isAuthenticated = false;
                this.userType = null;
                this.userName = null;
                
                // Recréer la navigation publique
                this.createNavigation();
                
                // Rediriger vers la page d'accueil
                window.location.href = '/index.html';
            } else {
                console.error('Erreur lors de la déconnexion');
                // Forcer la déconnexion côté client même si le serveur échoue
                localStorage.clear();
                sessionStorage.clear();
                this.isAuthenticated = false;
                this.userType = null;
                this.userName = null;
                this.createNavigation();
                window.location.href = '/index.html';
            }
        } catch (error) {
            console.error('Erreur lors de la déconnexion:', error);
            // Forcer la déconnexion côté client
            localStorage.clear();
            sessionStorage.clear();
            this.isAuthenticated = false;
            this.userType = null;
            this.userName = null;
            this.createNavigation();
            window.location.href = '/index.html';
        }
    }

    initEvents() {
        // Fermer le menu mobile lors du clic sur un lien
        document.addEventListener('click', (e) => {
            if (e.target.matches('.mobile-menu .nav-link')) {
                this.closeMobileMenu();
            }
            
            // Gérer la déconnexion
            if (e.target.closest('[onclick*="logout"]')) {
                e.preventDefault();
                this.logout();
            }
        });

        // Ajuster la marge du contenu principal
        this.adjustMainContent();
    }

    adjustMainContent() {
        const mainContent = document.querySelector('.main-content, main, .container');
        if (mainContent) {
            mainContent.style.marginTop = '70px';
        }
        
        // Responsive
        const mediaQuery = window.matchMedia('(max-width: 768px)');
        const handleMediaQuery = (e) => {
            if (mainContent) {
                mainContent.style.marginTop = e.matches ? '60px' : '70px';
            }
        };
        
        mediaQuery.addListener(handleMediaQuery);
        handleMediaQuery(mediaQuery);
    }
}

// Initialiser le système de navigation
let navigationSystem;

document.addEventListener('DOMContentLoaded', () => {
    navigationSystem = new NavigationSystem();
});

// Fonction globale pour la déconnexion (compatibilité)
function logout() {
    if (navigationSystem) {
        navigationSystem.logout();
    }
}

