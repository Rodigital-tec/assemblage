/**
 * Système de notifications en temps réel pour Assembl'âge
 * Gère l'affichage, la récupération et la mise à jour des notifications
 */

class NotificationSystem {
    constructor() {
        this.notifications = [];
        this.unreadCount = 0;
        this.isInitialized = false;
        this.refreshInterval = null;
        this.notificationContainer = null;
        this.notificationBadge = null;
        
        // Configuration
        this.config = {
            refreshInterval: 30000, // 30 secondes
            maxNotifications: 20,
            autoMarkReadDelay: 5000, // 5 secondes
            showToast: true
        };
        
        this.init();
    }
    
    /**
     * Initialiser le système de notifications
     */
    async init() {
        if (this.isInitialized) return;
        
        try {
            // Créer l'interface utilisateur
            this.createNotificationUI();
            
            // Charger les notifications initiales
            await this.loadNotifications();
            
            // Démarrer le rafraîchissement automatique
            this.startAutoRefresh();
            
            this.isInitialized = true;
            console.log('Système de notifications initialisé');
        } catch (error) {
            console.error('Erreur lors de l\'initialisation des notifications:', error);
        }
    }
    
    /**
     * Créer l'interface utilisateur des notifications
     */
    createNotificationUI() {
        // Créer le bouton de notifications dans la navigation
        const navbar = document.getElementById('navbar') || document.querySelector('nav');
        if (!navbar) {
            console.warn('Navigation non trouvée, impossible d\'ajouter le bouton notifications');
            return;
        }
        
        // Créer le bouton notifications
        const notificationButton = document.createElement('div');
        notificationButton.className = 'notification-button';
        notificationButton.innerHTML = `
            <button id="notifications-toggle" class="nav-notification-btn">
                <span class="notification-icon">🔔</span>
                <span id="notification-badge" class="notification-badge" style="display: none;">0</span>
            </button>
        `;
        
        // Créer le panneau de notifications
        const notificationPanel = document.createElement('div');
        notificationPanel.id = 'notification-panel';
        notificationPanel.className = 'notification-panel';
        notificationPanel.innerHTML = `
            <div class="notification-header">
                <h3>Notifications</h3>
                <button id="mark-all-read" class="mark-all-read-btn">Tout marquer comme lu</button>
            </div>
            <div id="notification-list" class="notification-list">
                <div class="loading-notifications">
                    <div class="spinner"></div>
                    <p>Chargement des notifications...</p>
                </div>
            </div>
            <div class="notification-footer">
                <button id="view-all-notifications" class="view-all-btn">Voir toutes les notifications</button>
            </div>
        `;
        
        // Ajouter les éléments au DOM
        navbar.appendChild(notificationButton);
        document.body.appendChild(notificationPanel);
        
        // Références aux éléments
        this.notificationBadge = document.getElementById('notification-badge');
        this.notificationContainer = document.getElementById('notification-list');
        
        // Ajouter les styles CSS
        this.addNotificationStyles();
        
        // Ajouter les événements
        this.attachEventListeners();
    }
    
    /**
     * Ajouter les styles CSS pour les notifications
     */
    addNotificationStyles() {
        const style = document.createElement('style');
        style.textContent = `
            .notification-button {
                position: relative;
                display: inline-block;
            }
            
            .nav-notification-btn {
                background: none;
                border: none;
                cursor: pointer;
                padding: 8px;
                border-radius: 50%;
                transition: background-color 0.3s ease;
                position: relative;
            }
            
            .nav-notification-btn:hover {
                background-color: rgba(255, 255, 255, 0.1);
            }
            
            .notification-icon {
                font-size: 20px;
                color: white;
            }
            
            .notification-badge {
                position: absolute;
                top: -2px;
                right: -2px;
                background: #ff4757;
                color: white;
                border-radius: 50%;
                padding: 2px 6px;
                font-size: 12px;
                font-weight: bold;
                min-width: 18px;
                height: 18px;
                display: flex;
                align-items: center;
                justify-content: center;
                animation: pulse 2s infinite;
            }
            
            @keyframes pulse {
                0% { transform: scale(1); }
                50% { transform: scale(1.1); }
                100% { transform: scale(1); }
            }
            
            .notification-panel {
                position: fixed;
                top: 60px;
                right: 20px;
                width: 350px;
                max-height: 500px;
                background: white;
                border-radius: 12px;
                box-shadow: 0 8px 25px rgba(0,0,0,0.15);
                z-index: 1000;
                display: none;
                overflow: hidden;
                border: 1px solid #e1e8ed;
            }
            
            .notification-panel.show {
                display: block;
                animation: slideIn 0.3s ease-out;
            }
            
            @keyframes slideIn {
                from {
                    opacity: 0;
                    transform: translateY(-10px);
                }
                to {
                    opacity: 1;
                    transform: translateY(0);
                }
            }
            
            .notification-header {
                padding: 15px 20px;
                border-bottom: 1px solid #e1e8ed;
                display: flex;
                justify-content: space-between;
                align-items: center;
                background: #f8f9fa;
            }
            
            .notification-header h3 {
                margin: 0;
                font-size: 16px;
                font-weight: 600;
                color: #2f3542;
            }
            
            .mark-all-read-btn {
                background: none;
                border: none;
                color: #6ab04c;
                font-size: 12px;
                cursor: pointer;
                padding: 4px 8px;
                border-radius: 4px;
                transition: background-color 0.3s ease;
            }
            
            .mark-all-read-btn:hover {
                background: rgba(106, 176, 76, 0.1);
            }
            
            .notification-list {
                max-height: 350px;
                overflow-y: auto;
            }
            
            .notification-item {
                padding: 15px 20px;
                border-bottom: 1px solid #f1f2f6;
                cursor: pointer;
                transition: background-color 0.3s ease;
                position: relative;
            }
            
            .notification-item:hover {
                background: #f8f9fa;
            }
            
            .notification-item.unread {
                background: #f0f8ff;
                border-left: 3px solid #6ab04c;
            }
            
            .notification-item.unread::before {
                content: '';
                position: absolute;
                left: 8px;
                top: 50%;
                transform: translateY(-50%);
                width: 8px;
                height: 8px;
                background: #6ab04c;
                border-radius: 50%;
            }
            
            .notification-title {
                font-weight: 600;
                color: #2f3542;
                margin-bottom: 4px;
                font-size: 14px;
            }
            
            .notification-message {
                color: #666;
                font-size: 13px;
                line-height: 1.4;
                margin-bottom: 6px;
            }
            
            .notification-time {
                color: #999;
                font-size: 11px;
            }
            
            .notification-footer {
                padding: 10px 20px;
                border-top: 1px solid #e1e8ed;
                background: #f8f9fa;
                text-align: center;
            }
            
            .view-all-btn {
                background: none;
                border: none;
                color: #6ab04c;
                font-size: 13px;
                cursor: pointer;
                padding: 5px 10px;
                border-radius: 4px;
                transition: background-color 0.3s ease;
            }
            
            .view-all-btn:hover {
                background: rgba(106, 176, 76, 0.1);
            }
            
            .loading-notifications {
                padding: 40px 20px;
                text-align: center;
                color: #666;
            }
            
            .spinner {
                width: 30px;
                height: 30px;
                border: 3px solid #f3f3f3;
                border-top: 3px solid #6ab04c;
                border-radius: 50%;
                animation: spin 1s linear infinite;
                margin: 0 auto 15px;
            }
            
            .empty-notifications {
                padding: 40px 20px;
                text-align: center;
                color: #666;
            }
            
            .empty-notifications .empty-icon {
                font-size: 48px;
                margin-bottom: 15px;
                opacity: 0.5;
            }
            
            .notification-toast {
                position: fixed;
                top: 80px;
                right: 20px;
                background: white;
                border-radius: 8px;
                box-shadow: 0 4px 12px rgba(0,0,0,0.15);
                padding: 15px 20px;
                max-width: 300px;
                z-index: 1001;
                border-left: 4px solid #6ab04c;
                animation: slideInToast 0.3s ease-out;
            }
            
            @keyframes slideInToast {
                from {
                    opacity: 0;
                    transform: translateX(100%);
                }
                to {
                    opacity: 1;
                    transform: translateX(0);
                }
            }
            
            .toast-title {
                font-weight: 600;
                color: #2f3542;
                margin-bottom: 4px;
                font-size: 14px;
            }
            
            .toast-message {
                color: #666;
                font-size: 13px;
            }
            
            @media (max-width: 768px) {
                .notification-panel {
                    right: 10px;
                    left: 10px;
                    width: auto;
                }
                
                .notification-toast {
                    right: 10px;
                    left: 10px;
                    max-width: none;
                }
            }
        `;
        document.head.appendChild(style);
    }
    
    /**
     * Attacher les événements
     */
    attachEventListeners() {
        // Toggle du panneau de notifications
        document.getElementById('notifications-toggle').addEventListener('click', (e) => {
            e.stopPropagation();
            this.toggleNotificationPanel();
        });
        
        // Marquer toutes les notifications comme lues
        document.getElementById('mark-all-read').addEventListener('click', () => {
            this.markAllAsRead();
        });
        
        // Fermer le panneau en cliquant ailleurs
        document.addEventListener('click', (e) => {
            const panel = document.getElementById('notification-panel');
            if (panel && !panel.contains(e.target) && !e.target.closest('.notification-button')) {
                this.hideNotificationPanel();
            }
        });
    }
    
    /**
     * Charger les notifications depuis l'API
     */
    async loadNotifications() {
        try {
            const response = await fetch('/api/notifications?limit=10', {
                method: 'GET',
                credentials: 'include'
            });
            
            if (!response.ok) {
                throw new Error(`Erreur HTTP: ${response.status}`);
            }
            
            const data = await response.json();
            
            if (data.success) {
                this.notifications = data.notifications;
                this.unreadCount = data.unread_count;
                this.updateNotificationDisplay();
            } else {
                console.error('Erreur lors du chargement des notifications:', data.error);
            }
        } catch (error) {
            console.error('Erreur lors du chargement des notifications:', error);
            this.showEmptyState();
        }
    }
    
    /**
     * Mettre à jour l'affichage des notifications
     */
    updateNotificationDisplay() {
        // Mettre à jour le badge
        this.updateBadge();
        
        // Mettre à jour la liste des notifications
        this.updateNotificationList();
    }
    
    /**
     * Mettre à jour le badge de notifications
     */
    updateBadge() {
        if (this.notificationBadge) {
            if (this.unreadCount > 0) {
                this.notificationBadge.textContent = this.unreadCount > 99 ? '99+' : this.unreadCount;
                this.notificationBadge.style.display = 'flex';
            } else {
                this.notificationBadge.style.display = 'none';
            }
        }
    }
    
    /**
     * Mettre à jour la liste des notifications
     */
    updateNotificationList() {
        if (!this.notificationContainer) return;
        
        if (this.notifications.length === 0) {
            this.showEmptyState();
            return;
        }
        
        const notificationHTML = this.notifications.map(notification => `
            <div class="notification-item ${!notification.is_read ? 'unread' : ''}" 
                 data-id="${notification.id}" 
                 onclick="notificationSystem.handleNotificationClick(${notification.id})">
                <div class="notification-title">${this.escapeHtml(notification.title)}</div>
                ${notification.message ? `<div class="notification-message">${this.escapeHtml(notification.message)}</div>` : ''}
                <div class="notification-time">${this.formatTime(notification.created_at)}</div>
            </div>
        `).join('');
        
        this.notificationContainer.innerHTML = notificationHTML;
    }
    
    /**
     * Afficher l'état vide
     */
    showEmptyState() {
        if (this.notificationContainer) {
            this.notificationContainer.innerHTML = `
                <div class="empty-notifications">
                    <div class="empty-icon">🔔</div>
                    <p>Aucune notification</p>
                </div>
            `;
        }
    }
    
    /**
     * Gérer le clic sur une notification
     */
    async handleNotificationClick(notificationId) {
        try {
            const notification = this.notifications.find(n => n.id === notificationId);
            if (!notification) return;
            
            // Marquer comme lue si pas encore lue
            if (!notification.is_read) {
                await this.markAsRead(notificationId);
            }
            
            // Traiter l'action selon le type de notification
            this.handleNotificationAction(notification);
            
            // Fermer le panneau
            this.hideNotificationPanel();
        } catch (error) {
            console.error('Erreur lors du clic sur la notification:', error);
        }
    }
    
    /**
     * Traiter l'action d'une notification
     */
    handleNotificationAction(notification) {
        if (notification.data) {
            // Redirection selon le type de notification
            switch (notification.type) {
                case 'message':
                    if (notification.data.conversation_id) {
                        window.location.href = `/messages-fixed.html?conversation=${notification.data.conversation_id}`;
                    } else {
                        window.location.href = '/messages-fixed.html';
                    }
                    break;
                case 'request':
                    if (notification.data.request_id) {
                        window.location.href = `/help-requests.html?id=${notification.data.request_id}`;
                    }
                    break;
                case 'appointment':
                    if (notification.data.appointment_id) {
                        window.location.href = `/calendar.html?appointment=${notification.data.appointment_id}`;
                    }
                    break;
                default:
                    // Action par défaut
                    break;
            }
        }
    }
    
    /**
     * Marquer une notification comme lue
     */
    async markAsRead(notificationId) {
        try {
            const response = await fetch(`/api/notifications/${notificationId}/read`, {
                method: 'POST',
                credentials: 'include'
            });
            
            if (response.ok) {
                // Mettre à jour localement
                const notification = this.notifications.find(n => n.id === notificationId);
                if (notification && !notification.is_read) {
                    notification.is_read = true;
                    notification.read_at = new Date().toISOString();
                    this.unreadCount = Math.max(0, this.unreadCount - 1);
                    this.updateNotificationDisplay();
                }
            }
        } catch (error) {
            console.error('Erreur lors du marquage comme lu:', error);
        }
    }
    
    /**
     * Marquer toutes les notifications comme lues
     */
    async markAllAsRead() {
        try {
            const response = await fetch('/api/notifications/read-all', {
                method: 'POST',
                credentials: 'include'
            });
            
            if (response.ok) {
                // Mettre à jour localement
                this.notifications.forEach(n => {
                    n.is_read = true;
                    n.read_at = new Date().toISOString();
                });
                this.unreadCount = 0;
                this.updateNotificationDisplay();
            }
        } catch (error) {
            console.error('Erreur lors du marquage de toutes les notifications:', error);
        }
    }
    
    /**
     * Afficher/masquer le panneau de notifications
     */
    toggleNotificationPanel() {
        const panel = document.getElementById('notification-panel');
        if (panel) {
            if (panel.classList.contains('show')) {
                this.hideNotificationPanel();
            } else {
                this.showNotificationPanel();
            }
        }
    }
    
    /**
     * Afficher le panneau de notifications
     */
    showNotificationPanel() {
        const panel = document.getElementById('notification-panel');
        if (panel) {
            panel.classList.add('show');
            // Recharger les notifications
            this.loadNotifications();
        }
    }
    
    /**
     * Masquer le panneau de notifications
     */
    hideNotificationPanel() {
        const panel = document.getElementById('notification-panel');
        if (panel) {
            panel.classList.remove('show');
        }
    }
    
    /**
     * Afficher une notification toast
     */
    showToast(title, message, duration = 5000) {
        if (!this.config.showToast) return;
        
        const toast = document.createElement('div');
        toast.className = 'notification-toast';
        toast.innerHTML = `
            <div class="toast-title">${this.escapeHtml(title)}</div>
            <div class="toast-message">${this.escapeHtml(message)}</div>
        `;
        
        document.body.appendChild(toast);
        
        // Supprimer automatiquement
        setTimeout(() => {
            toast.remove();
        }, duration);
    }
    
    /**
     * Démarrer le rafraîchissement automatique
     */
    startAutoRefresh() {
        if (this.refreshInterval) {
            clearInterval(this.refreshInterval);
        }
        
        this.refreshInterval = setInterval(() => {
            this.loadNotifications();
        }, this.config.refreshInterval);
    }
    
    /**
     * Arrêter le rafraîchissement automatique
     */
    stopAutoRefresh() {
        if (this.refreshInterval) {
            clearInterval(this.refreshInterval);
            this.refreshInterval = null;
        }
    }
    
    /**
     * Formater le temps relatif
     */
    formatTime(dateString) {
        const date = new Date(dateString);
        const now = new Date();
        const diffMs = now - date;
        const diffMins = Math.floor(diffMs / 60000);
        const diffHours = Math.floor(diffMs / 3600000);
        const diffDays = Math.floor(diffMs / 86400000);
        
        if (diffMins < 1) return 'À l\'instant';
        if (diffMins < 60) return `Il y a ${diffMins} min`;
        if (diffHours < 24) return `Il y a ${diffHours}h`;
        if (diffDays < 7) return `Il y a ${diffDays}j`;
        
        return date.toLocaleDateString('fr-FR', {
            day: 'numeric',
            month: 'short'
        });
    }
    
    /**
     * Échapper le HTML pour éviter les injections XSS
     */
    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
    
    /**
     * Détruire le système de notifications
     */
    destroy() {
        this.stopAutoRefresh();
        this.isInitialized = false;
        
        // Supprimer les éléments du DOM
        const panel = document.getElementById('notification-panel');
        const button = document.querySelector('.notification-button');
        
        if (panel) panel.remove();
        if (button) button.remove();
    }
}

// Instance globale du système de notifications
let notificationSystem = null;

// Initialiser automatiquement quand le DOM est prêt
document.addEventListener('DOMContentLoaded', function() {
    // Attendre un peu pour s'assurer que la navigation est chargée
    setTimeout(() => {
        if (!notificationSystem) {
            notificationSystem = new NotificationSystem();
        }
    }, 1000);
});

// Exposer globalement pour les autres scripts
window.NotificationSystem = NotificationSystem;
window.notificationSystem = notificationSystem;
