// Configuration de l'API backend
const API_BASE_URL = 'https://5001-itb52pwaoahg1upikz61n-f39a189e.manusvm.computer';

// Export pour utilisation dans les autres fichiers
window.API_BASE_URL = API_BASE_URL;
