#!/usr/bin/env node

const fs = require('fs');
const path = require('path');

// Template de base pour toutes les pages
const getPageTemplate = (title, content, additionalCSS = '', additionalJS = '') => `<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${title} - Assembl'âge</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="responsive_complete.css" rel="stylesheet">
    ${additionalCSS}
</head>
<body>
    <main>
        ${content}
    </main>
    
    <script src="responsive_complete.js"></script>
    ${additionalJS}
</body>
</html>`;

// Fonction pour extraire le contenu principal d'une page
function extractMainContent(htmlContent) {
    // Supprimer les balises html, head, body
    let content = htmlContent;
    
    // Extraire le contenu entre <body> et </body>
    const bodyMatch = content.match(/<body[^>]*>([\s\S]*?)<\/body>/i);
    if (bodyMatch) {
        content = bodyMatch[1];
    }
    
    // Supprimer les anciennes navigations
    content = content.replace(/<nav[^>]*>[\s\S]*?<\/nav>/gi, '');
    content = content.replace(/<header[^>]*>[\s\S]*?<\/header>/gi, '');
    content = content.replace(/<aside[^>]*>[\s\S]*?<\/aside>/gi, '');
    content = content.replace(/<div[^>]*class="[^"]*navbar[^"]*"[^>]*>[\s\S]*?<\/div>/gi, '');
    content = content.replace(/<div[^>]*class="[^"]*sidebar[^"]*"[^>]*>[\s\S]*?<\/div>/gi, '');
    content = content.replace(/<div[^>]*class="[^"]*overlay[^"]*"[^>]*>[\s\S]*?<\/div>/gi, '');
    
    // Supprimer les anciens scripts de navigation
    content = content.replace(/<script[^>]*src="[^"]*navigation[^"]*"[^>]*><\/script>/gi, '');
    content = content.replace(/<script[^>]*>[\s\S]*?navigation[\s\S]*?<\/script>/gi, '');
    
    // Nettoyer les balises main existantes
    content = content.replace(/<\/?main[^>]*>/gi, '');
    
    return content.trim();
}

// Fonction pour extraire le titre de la page
function extractTitle(htmlContent) {
    const titleMatch = htmlContent.match(/<title[^>]*>([^<]*)<\/title>/i);
    if (titleMatch) {
        return titleMatch[1].replace(' - Assembl\'âge', '');
    }
    return 'Page';
}

// Fonction pour extraire le CSS additionnel
function extractAdditionalCSS(htmlContent) {
    const cssLinks = [];
    const styleBlocks = [];
    
    // Extraire les liens CSS (sauf ceux qu'on remplace)
    const linkMatches = htmlContent.matchAll(/<link[^>]*href="([^"]*\.css)"[^>]*>/gi);
    for (const match of linkMatches) {
        const href = match[1];
        if (!href.includes('theme') && !href.includes('responsive') && !href.includes('navigation')) {
            cssLinks.push(match[0]);
        }
    }
    
    // Extraire les blocs <style>
    const styleMatches = htmlContent.matchAll(/<style[^>]*>([\s\S]*?)<\/style>/gi);
    for (const match of styleMatches) {
        styleBlocks.push(match[0]);
    }
    
    return [...cssLinks, ...styleBlocks].join('\n    ');
}

// Fonction pour extraire le JavaScript additionnel
function extractAdditionalJS(htmlContent) {
    const jsScripts = [];
    
    // Extraire les scripts (sauf ceux qu'on remplace)
    const scriptMatches = htmlContent.matchAll(/<script[^>]*>([\s\S]*?)<\/script>/gi);
    for (const match of scriptMatches) {
        const content = match[1];
        if (!content.includes('navigation') && !content.includes('ResponsiveNav') && content.trim()) {
            jsScripts.push(match[0]);
        }
    }
    
    // Extraire les scripts externes
    const srcMatches = htmlContent.matchAll(/<script[^>]*src="([^"]*)"[^>]*><\/script>/gi);
    for (const match of srcMatches) {
        const src = match[1];
        if (!src.includes('navigation') && !src.includes('responsive')) {
            jsScripts.push(match[0]);
        }
    }
    
    return jsScripts.join('\n    ');
}

// Pages à traiter
const pages = [
    'index.html',
    'profile.html',
    'profile-aidant-complet.html',
    'profile-senior-complet.html',
    'messages.html',
    'help-requests.html',
    'my-service-offers.html',
    'search-simple.html',
    'search-geolocalized.html',
    'admin.html'
];

console.log('🚀 Application du design responsive à toutes les pages...\n');

pages.forEach(pageName => {
    try {
        if (!fs.existsSync(pageName)) {
            console.log(`⚠️  ${pageName} n'existe pas, ignoré`);
            return;
        }
        
        // Lire le contenu actuel
        const currentContent = fs.readFileSync(pageName, 'utf8');
        
        // Extraire les éléments
        const title = extractTitle(currentContent);
        const mainContent = extractMainContent(currentContent);
        const additionalCSS = extractAdditionalCSS(currentContent);
        const additionalJS = extractAdditionalJS(currentContent);
        
        // Créer la nouvelle page
        const newContent = getPageTemplate(title, mainContent, additionalCSS, additionalJS);
        
        // Sauvegarder l'ancienne version
        fs.writeFileSync(`${pageName}.backup`, currentContent);
        
        // Écrire la nouvelle version
        fs.writeFileSync(pageName, newContent);
        
        console.log(`✅ ${pageName} - Design responsive appliqué`);
        
    } catch (error) {
        console.error(`❌ Erreur avec ${pageName}:`, error.message);
    }
});

console.log('\n🎉 Design responsive appliqué à toutes les pages !');
console.log('📁 Les anciennes versions sont sauvegardées avec l\'extension .backup');

