// ===== NAVIGATION RESPONSIVE UNIVERSELLE =====

class ResponsiveNavigation {
    constructor() {
        this.mobileMenuBtn = null;
        this.mobileMenu = null;
        this.mobileOverlay = null;
        this.isMenuOpen = false;
        this.currentUser = null;
        this.userType = 'senior';
        
        this.init();
    }

    init() {
        // Attendre que le DOM soit chargé
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => this.setup());
        } else {
            this.setup();
        }
    }

    setup() {
        this.createNavigation();
        this.setupEventListeners();
        this.loadCurrentUser();
        this.handleResize();
    }

    createNavigation() {
        // Vérifier si la navigation existe déjà
        if (document.querySelector('.responsive-navbar')) {
            this.setupExistingNavigation();
            return;
        }

        // Créer la navigation complète
        const navbar = document.createElement('nav');
        navbar.className = 'responsive-navbar';
        navbar.innerHTML = `
            <a href="index.html" class="navbar-brand">
                <img src="logo.png" alt="Assembl'âge">
                <span>Assembl'âge</span>
            </a>
            
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a href="dashboard.html" class="nav-link" data-page="dashboard">
                        <i class="fas fa-tachometer-alt"></i>
                        Tableau de bord
                    </a>
                </li>
                <li class="nav-item">
                    <a href="help-requests.html" class="nav-link" data-page="requests" id="nav-requests">
                        <i class="fas fa-hands-helping"></i>
                        <span id="nav-requests-text">Mes demandes</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="messages.html" class="nav-link" data-page="messages">
                        <i class="fas fa-envelope"></i>
                        Messages
                        <span class="nav-badge" id="nav-message-count">0</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="profile.html" class="nav-link" data-page="profile">
                        <i class="fas fa-user"></i>
                        Mon profil
                    </a>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link" onclick="logout()">
                        <i class="fas fa-sign-out-alt"></i>
                        Déconnexion
                    </a>
                </li>
            </ul>
            
            <button class="mobile-menu-btn" id="mobileMenuBtn">
                <div class="hamburger-line"></div>
                <div class="hamburger-line"></div>
                <div class="hamburger-line"></div>
            </button>
        `;

        // Créer le menu mobile
        const mobileMenu = document.createElement('div');
        mobileMenu.className = 'mobile-menu';
        mobileMenu.id = 'mobileMenu';
        mobileMenu.innerHTML = `
            <ul class="mobile-nav-list">
                <li class="mobile-nav-item">
                    <a href="dashboard.html" class="mobile-nav-link" data-page="dashboard">
                        <i class="fas fa-tachometer-alt mobile-nav-icon"></i>
                        Tableau de bord
                    </a>
                </li>
                <li class="mobile-nav-item">
                    <a href="help-requests.html" class="mobile-nav-link" data-page="requests" id="mobile-nav-requests">
                        <i class="fas fa-hands-helping mobile-nav-icon"></i>
                        <span id="mobile-nav-requests-text">Mes demandes</span>
                    </a>
                </li>
                <li class="mobile-nav-item">
                    <a href="messages.html" class="mobile-nav-link" data-page="messages">
                        <i class="fas fa-envelope mobile-nav-icon"></i>
                        Messages
                        <span class="nav-badge" id="mobile-message-count">0</span>
                    </a>
                </li>
                <li class="mobile-nav-item">
                    <a href="profile.html" class="mobile-nav-link" data-page="profile">
                        <i class="fas fa-user mobile-nav-icon"></i>
                        Mon profil
                    </a>
                </li>
                <li class="mobile-nav-item">
                    <a href="search-simple.html" class="mobile-nav-link" data-page="search">
                        <i class="fas fa-search mobile-nav-icon"></i>
                        Recherche
                    </a>
                </li>
                <li class="mobile-nav-item">
                    <a href="#" class="mobile-nav-link" onclick="contactAdmin()">
                        <i class="fas fa-headset mobile-nav-icon"></i>
                        Contact admin
                    </a>
                </li>
                <li class="mobile-nav-item">
                    <a href="#" class="mobile-nav-link" onclick="logout()">
                        <i class="fas fa-sign-out-alt mobile-nav-icon"></i>
                        Déconnexion
                    </a>
                </li>
            </ul>
        `;

        // Créer l'overlay
        const overlay = document.createElement('div');
        overlay.className = 'mobile-overlay';
        overlay.id = 'mobileOverlay';

        // Insérer au début du body
        document.body.insertBefore(navbar, document.body.firstChild);
        document.body.insertBefore(mobileMenu, document.body.firstChild.nextSibling);
        document.body.insertBefore(overlay, document.body.firstChild.nextSibling.nextSibling);

        // Ajouter la classe main-content au contenu principal
        this.setupMainContent();
        this.setupExistingNavigation();
    }

    setupExistingNavigation() {
        this.mobileMenuBtn = document.getElementById('mobileMenuBtn');
        this.mobileMenu = document.getElementById('mobileMenu');
        this.mobileOverlay = document.getElementById('mobileOverlay');
        
        // Marquer la page active
        this.setActivePage();
    }

    setupMainContent() {
        // Trouver le contenu principal et lui ajouter la classe appropriée
        const mainElements = document.querySelectorAll('main, .container, .content, body > div:not(.responsive-navbar):not(.mobile-menu):not(.mobile-overlay)');
        
        if (mainElements.length > 0) {
            const mainContent = mainElements[0];
            if (!mainContent.classList.contains('main-content')) {
                mainContent.classList.add('main-content');
            }
        } else {
            // Si aucun élément principal trouvé, wrapper le contenu existant
            const bodyContent = Array.from(document.body.children).filter(child => 
                !child.classList.contains('responsive-navbar') && 
                !child.classList.contains('mobile-menu') && 
                !child.classList.contains('mobile-overlay')
            );
            
            if (bodyContent.length > 0) {
                const wrapper = document.createElement('main');
                wrapper.className = 'main-content';
                
                bodyContent.forEach(element => {
                    wrapper.appendChild(element);
                });
                
                document.body.appendChild(wrapper);
            }
        }
    }

    setupEventListeners() {
        // Menu mobile toggle
        if (this.mobileMenuBtn) {
            this.mobileMenuBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.toggleMobileMenu();
            });
        }

        // Overlay click
        if (this.mobileOverlay) {
            this.mobileOverlay.addEventListener('click', () => {
                this.closeMobileMenu();
            });
        }

        // Fermer le menu sur les liens
        const mobileLinks = document.querySelectorAll('.mobile-nav-link');
        mobileLinks.forEach(link => {
            link.addEventListener('click', () => {
                if (!link.getAttribute('href').startsWith('#')) {
                    this.closeMobileMenu();
                }
            });
        });

        // Resize handler
        window.addEventListener('resize', () => {
            this.handleResize();
        });

        // Escape key
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && this.isMenuOpen) {
                this.closeMobileMenu();
            }
        });
    }

    toggleMobileMenu() {
        if (this.isMenuOpen) {
            this.closeMobileMenu();
        } else {
            this.openMobileMenu();
        }
    }

    openMobileMenu() {
        this.isMenuOpen = true;
        this.mobileMenuBtn?.classList.add('active');
        this.mobileMenu?.classList.add('show');
        this.mobileOverlay?.classList.add('show');
        document.body.style.overflow = 'hidden';
    }

    closeMobileMenu() {
        this.isMenuOpen = false;
        this.mobileMenuBtn?.classList.remove('active');
        this.mobileMenu?.classList.remove('show');
        this.mobileOverlay?.classList.remove('show');
        document.body.style.overflow = '';
    }

    handleResize() {
        if (window.innerWidth > 768 && this.isMenuOpen) {
            this.closeMobileMenu();
        }
    }

    setActivePage() {
        const currentPage = this.getCurrentPage();
        
        // Retirer toutes les classes active
        document.querySelectorAll('.nav-link, .mobile-nav-link').forEach(link => {
            link.classList.remove('active');
        });

        // Ajouter la classe active aux liens correspondants
        document.querySelectorAll(`[data-page="${currentPage}"]`).forEach(link => {
            link.classList.add('active');
        });
    }

    getCurrentPage() {
        const path = window.location.pathname;
        const filename = path.split('/').pop().split('.')[0];
        
        const pageMap = {
            'dashboard': 'dashboard',
            'help-requests': 'requests',
            'my-service-offers': 'requests',
            'messages': 'messages',
            'profile': 'profile',
            'profile-aidant-complet': 'profile',
            'profile-senior-complet': 'profile',
            'search-simple': 'search',
            'search-geolocalized': 'search'
        };

        return pageMap[filename] || 'dashboard';
    }

    async loadCurrentUser() {
        try {
            const response = await fetch('/api/auth/current-user');
            const data = await response.json();
            
            if (data.success && data.user) {
                this.currentUser = data.user;
                this.userType = data.user.user_type || 'senior';
                this.adaptNavigationForUserType();
                this.updateMessageCount();
            }
        } catch (error) {
            console.error('Erreur lors du chargement de l\'utilisateur:', error);
            // Utiliser le localStorage comme fallback
            this.userType = localStorage.getItem('userType') || 'senior';
            this.adaptNavigationForUserType();
        }
    }

    adaptNavigationForUserType() {
        const elements = {
            navRequestsText: document.getElementById('nav-requests-text'),
            mobileNavRequestsText: document.getElementById('mobile-nav-requests-text'),
            navRequests: document.getElementById('nav-requests'),
            mobileNavRequests: document.getElementById('mobile-nav-requests')
        };

        if (this.userType === 'aidant') {
            // Adapter pour les aidants
            if (elements.navRequestsText) elements.navRequestsText.textContent = 'Mes offres';
            if (elements.mobileNavRequestsText) elements.mobileNavRequestsText.textContent = 'Mes offres';
            if (elements.navRequests) elements.navRequests.href = 'my-service-offers.html';
            if (elements.mobileNavRequests) elements.mobileNavRequests.href = 'my-service-offers.html';
        } else {
            // Adapter pour les seniors
            if (elements.navRequestsText) elements.navRequestsText.textContent = 'Mes demandes';
            if (elements.mobileNavRequestsText) elements.mobileNavRequestsText.textContent = 'Mes demandes';
            if (elements.navRequests) elements.navRequests.href = 'help-requests.html';
            if (elements.mobileNavRequests) elements.mobileNavRequests.href = 'help-requests.html';
        }
    }

    async updateMessageCount() {
        try {
            const response = await fetch('/api/messages/count');
            const data = await response.json();
            
            if (data.success) {
                const count = data.count || 0;
                const badges = document.querySelectorAll('#nav-message-count, #mobile-message-count');
                badges.forEach(badge => {
                    badge.textContent = count;
                    badge.style.display = count > 0 ? 'inline' : 'none';
                });
            }
        } catch (error) {
            console.error('Erreur lors du chargement du nombre de messages:', error);
        }
    }
}

// Fonctions globales
function logout() {
    if (confirm('Êtes-vous sûr de vouloir vous déconnecter ?')) {
        fetch('/api/auth/logout', { method: 'POST' })
            .then(() => {
                localStorage.clear();
                window.location.href = '/';
            })
            .catch(() => {
                window.location.href = '/';
            });
    }
}

function contactAdmin() {
    window.location.href = 'mailto:admin@assemblage.com';
}

// Initialiser la navigation responsive
const responsiveNav = new ResponsiveNavigation();

// Export pour utilisation dans d'autres scripts
if (typeof module !== 'undefined' && module.exports) {
    module.exports = ResponsiveNavigation;
}

